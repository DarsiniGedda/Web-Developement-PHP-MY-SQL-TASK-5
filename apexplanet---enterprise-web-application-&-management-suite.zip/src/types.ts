export type UserRole = 'admin' | 'manager' | 'customer' | 'guest';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  department?: string;
  lastLogin: string;
  token?: string;
  status: 'active' | 'suspended';
}

export type ProductCategory = 'Footwear' | 'Apparel' | 'Accessories' | 'Electronics' | 'Office & Tech';

export interface Product {
  id: string;
  name: string;
  sku: string;
  category: ProductCategory;
  price: number;
  originalPrice?: number;
  stock: number;
  status: 'In Stock' | 'Low Stock' | 'Out of Stock';
  rating: number;
  reviewsCount: number;
  description: string;
  tags: string[];
  brand: string;
  imageUrl: string;
  badge?: 'Hot' | 'Sale' | 'New' | 'Featured';
  specs?: Record<string, string>;
  createdAt: string;
  updatedAt: string;
}

export type AuditAction = 
  | 'CREATE_PRODUCT'
  | 'UPDATE_PRODUCT'
  | 'DELETE_PRODUCT'
  | 'BULK_ACTION'
  | 'USER_LOGIN'
  | 'USER_LOGOUT'
  | 'ROLE_SWITCH'
  | 'SECURITY_CONFIG'
  | 'ORDER_CHECKOUT'
  | 'EXPORT_DATA'
  | 'TEST_SUITE_RUN';

export interface AuditLog {
  id: string;
  timestamp: string;
  action: AuditAction;
  actor: string;
  actorRole: UserRole;
  target: string;
  details: string;
  status: 'SUCCESS' | 'WARNING' | 'DENIED';
  ipAddress: string;
}

export interface FilterState {
  searchQuery: string;
  category: string;
  stockStatus: string;
  minPrice: number;
  maxPrice: number;
  minRating: number;
  inStockOnly: boolean;
  sortBy: 'price-asc' | 'price-desc' | 'rating-desc' | 'name-asc' | 'stock-desc' | 'newest';
  page: number;
  itemsPerPage: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
}

export interface Order {
  id: string;
  items: CartItem[];
  subtotal: number;
  tax: number;
  discount: number;
  shipping: number;
  total: number;
  customerName: string;
  customerEmail: string;
  status: 'Processing' | 'Shipped' | 'Delivered';
  createdAt: string;
  paymentMethod: string;
}

export interface SecuritySettings {
  rateLimitingEnabled: boolean;
  xssSanitizationStrict: boolean;
  sessionTimeoutMinutes: number;
  requireTwoFactor: boolean;
  sqlInjectionShield: boolean;
  auditLoggingEnabled: boolean;
}

export type TestCaseCategory = 'CRUD' | 'Authentication' | 'Search & Filter' | 'Pagination' | 'Security & RBAC' | 'Cart & Orders';

export interface TestCase {
  id: string;
  name: string;
  category: TestCaseCategory;
  description: string;
  status: 'pending' | 'running' | 'passed' | 'failed';
  durationMs?: number;
  details?: string;
  steps: string[];
}

export interface InternshipCertificateData {
  studentName: string;
  internId: string;
  domain: string;
  taskTitle: string;
  timeline: string;
  completionDate: string;
  grade: string;
  mentorName: string;
  companyName: string;
  certificateId: string;
  verificationCode: string;
}
