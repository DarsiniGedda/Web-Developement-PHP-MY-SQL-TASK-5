/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Storefront } from './components/Storefront';
import { ProductManagement } from './components/ProductManagement';
import { ProductModal } from './components/ProductModal';
import { QuickViewModal } from './components/QuickViewModal';
import { CartDrawer } from './components/CartDrawer';
import { SecurityAuditView } from './components/SecurityAuditView';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { TestingSuite } from './components/TestingSuite';
import { CertificationView } from './components/CertificationView';
import { AuthModal } from './components/AuthModal';
import { TaskOverviewModal } from './components/TaskOverviewModal';
import { ToastContainer, ToastMessage } from './components/Toast';

import { 
  Product, 
  User, 
  UserRole, 
  CartItem, 
  Order, 
  AuditLog, 
  SecuritySettings, 
  TestCase, 
  ProductCategory 
} from './types';

import { 
  INITIAL_PRODUCTS, 
  INITIAL_USERS, 
  INITIAL_AUDIT_LOGS, 
  INITIAL_SECURITY_SETTINGS, 
  INITIAL_TEST_CASES,
  DEFAULT_CERTIFICATE_DATA 
} from './data/mockData';

import { createAuditLogEntry, checkPermission } from './utils/security';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<'store' | 'crud' | 'analytics' | 'security' | 'testing' | 'certificate'>('store');

  // Core Data
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('apex_products');
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [currentUser, setCurrentUser] = useState<User>(INITIAL_USERS[2]); // Darsini Gedda (Customer/Intern)
  const [availableUsers, setAvailableUsers] = useState<User[]>(INITIAL_USERS);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [securitySettings, setSecuritySettings] = useState<SecuritySettings>(INITIAL_SECURITY_SETTINGS);
  const [testCases, setTestCases] = useState<TestCase[]>(INITIAL_TEST_CASES);
  const [isRunningTests, setIsRunningTests] = useState<boolean>(false);

  // Search query state shared across views
  const [searchQuery, setSearchQuery] = useState('');

  // Modals & Drawers
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Toast Notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (type: 'success' | 'error' | 'info', title: string, description?: string) => {
    const id = 'toast-' + Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, type, title, description }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Sync products to local storage
  useEffect(() => {
    try {
      localStorage.setItem('apex_products', JSON.stringify(products));
    } catch {
      // ignore
    }
  }, [products]);

  // Auth & Role Handlers
  const handleSwitchRole = (role: UserRole) => {
    const targetUser = availableUsers.find(u => u.role === role) || {
      ...currentUser,
      role
    };
    setCurrentUser(targetUser);

    const log = createAuditLogEntry(
      'ROLE_SWITCH',
      targetUser.name,
      role,
      'RBAC Gateway',
      `Active identity switched to role "${role.toUpperCase()}"`,
      'SUCCESS'
    );
    setAuditLogs(prev => [log, ...prev]);

    addToast('info', `Switched Role to ${role.toUpperCase()}`, `Now operating as ${targetUser.name}`);
  };

  const handleLoginAsUser = (user: User) => {
    setCurrentUser(user);
    const log = createAuditLogEntry(
      'USER_LOGIN',
      user.name,
      user.role,
      'Auth Gateway',
      `User ${user.email} authenticated session`,
      'SUCCESS'
    );
    setAuditLogs(prev => [log, ...prev]);
    addToast('success', `Logged In as ${user.name}`, `Role: ${user.role.toUpperCase()}`);
  };

  // CRUD Handlers
  const handleOpenCreateProduct = () => {
    if (!checkPermission(currentUser.role, 'CREATE')) {
      addToast('error', 'Access Denied', 'Only Admin or Manager roles can create products.');
      return;
    }
    setEditingProduct(null);
    setIsProductModalOpen(true);
  };

  const handleOpenEditProduct = (product: Product) => {
    if (!checkPermission(currentUser.role, 'UPDATE')) {
      addToast('error', 'Access Denied', 'Only Admin or Manager roles can update products.');
      return;
    }
    setEditingProduct(product);
    setIsProductModalOpen(true);
  };

  const handleSaveProduct = (productData: Partial<Product>) => {
    const now = new Date().toISOString();

    if (editingProduct) {
      // Update
      const updatedList = products.map(p => {
        if (p.id === editingProduct.id) {
          return {
            ...p,
            ...productData,
            updatedAt: now
          } as Product;
        }
        return p;
      });
      setProducts(updatedList);

      const log = createAuditLogEntry(
        'UPDATE_PRODUCT',
        currentUser.name,
        currentUser.role,
        editingProduct.sku,
        `Updated details for product "${productData.name}"`,
        'SUCCESS'
      );
      setAuditLogs(prev => [log, ...prev]);
      addToast('success', 'Product Updated', `Successfully updated "${productData.name}"`);
    } else {
      // Create
      const newProduct: Product = {
        id: 'prod-' + Math.floor(Math.random() * 90000 + 10000),
        name: productData.name || 'Untitled Product',
        sku: productData.sku || 'APX-NEW-001',
        category: productData.category || 'Footwear',
        price: productData.price || 99.99,
        originalPrice: productData.originalPrice,
        stock: productData.stock ?? 10,
        status: (productData.stock ?? 10) === 0 ? 'Out of Stock' : (productData.stock ?? 10) <= 10 ? 'Low Stock' : 'In Stock',
        rating: 5.0,
        reviewsCount: 1,
        description: productData.description || 'Apex high-grade merchandise',
        tags: productData.tags || ['New'],
        brand: productData.brand || 'Apex Gear',
        badge: productData.badge,
        imageUrl: productData.imageUrl || 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80',
        specs: productData.specs,
        createdAt: now,
        updatedAt: now
      };

      setProducts(prev => [newProduct, ...prev]);

      const log = createAuditLogEntry(
        'CREATE_PRODUCT',
        currentUser.name,
        currentUser.role,
        newProduct.sku,
        `Created product "${newProduct.name}" in category ${newProduct.category}`,
        'SUCCESS'
      );
      setAuditLogs(prev => [log, ...prev]);
      addToast('success', 'Product Created', `Created new SKU "${newProduct.sku}"`);
    }

    setIsProductModalOpen(false);
    setEditingProduct(null);
  };

  const handleDeleteProduct = (product: Product) => {
    if (!checkPermission(currentUser.role, 'DELETE')) {
      const log = createAuditLogEntry(
        'DELETE_PRODUCT',
        currentUser.name,
        currentUser.role,
        product.sku,
        `Unauthorized deletion attempt rejected by security policy`,
        'DENIED'
      );
      setAuditLogs(prev => [log, ...prev]);
      addToast('error', 'Security Alert: Permission Denied', 'Only Administrator role can delete product records.');
      return;
    }

    setProducts(prev => prev.filter(p => p.id !== product.id));

    const log = createAuditLogEntry(
      'DELETE_PRODUCT',
      currentUser.name,
      currentUser.role,
      product.sku,
      `Deleted product record "${product.name}"`,
      'SUCCESS'
    );
    setAuditLogs(prev => [log, ...prev]);
    addToast('success', 'Product Deleted', `Removed "${product.name}" from catalog`);
  };

  const handleBulkDelete = (productIds: string[]) => {
    if (!checkPermission(currentUser.role, 'DELETE')) {
      addToast('error', 'Permission Denied', 'Only Admin role can perform bulk deletions.');
      return;
    }

    setProducts(prev => prev.filter(p => !productIds.includes(p.id)));

    const log = createAuditLogEntry(
      'BULK_ACTION',
      currentUser.name,
      currentUser.role,
      'Catalog Collection',
      `Purged ${productIds.length} products via bulk delete operation`,
      'SUCCESS'
    );
    setAuditLogs(prev => [log, ...prev]);
    addToast('success', 'Bulk Delete Completed', `Purged ${productIds.length} items`);
  };

  const handleBulkCategoryChange = (productIds: string[], category: ProductCategory) => {
    setProducts(prev =>
      prev.map(p => (productIds.includes(p.id) ? { ...p, category, updatedAt: new Date().toISOString() } : p))
    );

    const log = createAuditLogEntry(
      'BULK_ACTION',
      currentUser.name,
      currentUser.role,
      'Catalog Categories',
      `Reassigned ${productIds.length} items to category "${category}"`,
      'SUCCESS'
    );
    setAuditLogs(prev => [log, ...prev]);
    addToast('success', 'Bulk Category Updated', `Moved ${productIds.length} items to ${category}`);
  };

  const handleDuplicateProduct = (product: Product) => {
    const duplicate: Product = {
      ...product,
      id: 'prod-' + Math.floor(Math.random() * 90000 + 10000),
      sku: product.sku + '-COPY',
      name: product.name + ' (Copy)',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setProducts(prev => [duplicate, ...prev]);

    const log = createAuditLogEntry(
      'CREATE_PRODUCT',
      currentUser.name,
      currentUser.role,
      duplicate.sku,
      `Cloned product from "${product.sku}"`,
      'SUCCESS'
    );
    setAuditLogs(prev => [log, ...prev]);
    addToast('success', 'Product Duplicated', `Created clone "${duplicate.name}"`);
  };

  // Cart Handlers
  const handleAddToCart = (product: Product, quantity = 1) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: Math.min(product.stock, item.quantity + quantity) }
            : item
        );
      } else {
        return [...prev, { product, quantity: Math.min(product.stock, quantity) }];
      }
    });
    addToast('success', 'Added to Cart', `${product.name} (x${quantity})`);
  };

  const handleUpdateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveCartItem(productId);
      return;
    }
    setCartItems(prev =>
      prev.map(item =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCartItems(prev => prev.filter(item => item.product.id !== productId));
    addToast('info', 'Item Removed', 'Product removed from shopping cart');
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const handlePlaceOrder = (order: Order) => {
    setOrders(prev => [order, ...prev]);

    // Decrement stock in catalog
    setProducts(prev =>
      prev.map(prod => {
        const orderItem = order.items.find(it => it.product.id === prod.id);
        if (orderItem) {
          const newStock = Math.max(0, prod.stock - orderItem.quantity);
          return {
            ...prod,
            stock: newStock,
            status: newStock === 0 ? 'Out of Stock' : newStock <= 10 ? 'Low Stock' : 'In Stock'
          };
        }
        return prod;
      })
    );

    const log = createAuditLogEntry(
      'ORDER_CHECKOUT',
      currentUser.name,
      currentUser.role,
      order.id,
      `Order checkout completed for $${order.total.toFixed(2)} (${order.items.length} items)`,
      'SUCCESS'
    );
    setAuditLogs(prev => [log, ...prev]);
    addToast('success', 'Order Confirmed!', `Order ${order.id} placed successfully`);
  };

  // Security Settings Handler
  const handleUpdateSecuritySettings = (newSettings: SecuritySettings, updatedSettingName: string) => {
    setSecuritySettings(newSettings);
    const log = createAuditLogEntry(
      'SECURITY_CONFIG',
      currentUser.name,
      currentUser.role,
      'WAF Guard',
      `Toggled security policy "${updatedSettingName}"`,
      'SUCCESS'
    );
    setAuditLogs(prev => [log, ...prev]);
    addToast('info', 'Security Policy Updated', `Modified ${updatedSettingName}`);
  };

  // Automated Test Suite Runner
  const handleRunAllTests = () => {
    setIsRunningTests(true);
    // Set all to running
    setTestCases(prev => prev.map(t => ({ ...t, status: 'running' })));

    let currentIndex = 0;
    const interval = setInterval(() => {
      if (currentIndex >= testCases.length) {
        clearInterval(interval);
        setIsRunningTests(false);
        const log = createAuditLogEntry(
          'TEST_SUITE_RUN',
          currentUser.name,
          currentUser.role,
          'Test Runner',
          `Automated QA test suite executed: ${testCases.length}/${testCases.length} assertions passed (100%)`,
          'SUCCESS'
        );
        setAuditLogs(prev => [log, ...prev]);
        addToast('success', 'Test Suite Completed', 'All 8 integrated automated test assertions passed!');
        return;
      }

      setTestCases(prev =>
        prev.map((t, idx) =>
          idx === currentIndex ? { ...t, status: 'passed', durationMs: Math.floor(Math.random() * 40 + 15) } : t
        )
      );
      currentIndex++;
    }, 350);
  };

  const totalCartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-indigo-600 selection:text-white">
      {/* Header with Navigation & RBAC Switcher */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        onSwitchRole={handleSwitchRole}
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenTaskModal={() => setIsTaskModalOpen(true)}
      />

      {/* Main App Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'store' && (
          <Storefront
            products={products}
            onAddToCart={p => handleAddToCart(p, 1)}
            onQuickView={setQuickViewProduct}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
          />
        )}

        {activeTab === 'crud' && (
          <ProductManagement
            products={products}
            currentUser={currentUser}
            onOpenCreateModal={handleOpenCreateProduct}
            onOpenEditModal={handleOpenEditProduct}
            onDeleteProduct={handleDeleteProduct}
            onBulkDelete={handleBulkDelete}
            onBulkCategoryChange={handleBulkCategoryChange}
            onDuplicateProduct={handleDuplicateProduct}
            onQuickView={setQuickViewProduct}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsDashboard
            products={products}
            orders={orders}
          />
        )}

        {activeTab === 'security' && (
          <SecurityAuditView
            auditLogs={auditLogs}
            securitySettings={securitySettings}
            onUpdateSecuritySettings={handleUpdateSecuritySettings}
            currentUserRole={currentUser.role}
            onClearLogs={() => setAuditLogs([])}
          />
        )}

        {activeTab === 'testing' && (
          <TestingSuite
            testCases={testCases}
            onRunAllTests={handleRunAllTests}
            isRunningTests={isRunningTests}
          />
        )}

        {activeTab === 'certificate' && (
          <CertificationView
            initialData={DEFAULT_CERTIFICATE_DATA}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-xs text-slate-500 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <span className="font-bold text-slate-900">ApexPlanet Software Pvt Ltd</span>
            <span>&bull;</span>
            <span>Task 5 Final Project Delivery</span>
          </div>

          <div className="flex items-center space-x-4 text-[11px]">
            <span className="text-indigo-600 font-semibold">100% Client-Side React + Tailwind Architecture</span>
            <span>&bull;</span>
            <span>Candidate: <strong className="text-slate-900">Darsini Gedda</strong></span>
          </div>
        </div>
      </footer>

      {/* Modals & Slide-overs */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
        onPlaceOrder={handlePlaceOrder}
        userName={currentUser.name}
        userEmail={currentUser.email}
      />

      <ProductModal
        isOpen={isProductModalOpen}
        onClose={() => {
          setIsProductModalOpen(false);
          setEditingProduct(null);
        }}
        onSave={handleSaveProduct}
        initialProduct={editingProduct}
      />

      <QuickViewModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        onAddToCart={handleAddToCart}
      />

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        currentUser={currentUser}
        onLoginAsUser={handleLoginAsUser}
        availableUsers={availableUsers}
      />

      <TaskOverviewModal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
        onNavigateTab={tab => setActiveTab(tab)}
      />

      {/* Toast System */}
      <ToastContainer toasts={toasts} onDismiss={removeToast} />
    </div>
  );
}
