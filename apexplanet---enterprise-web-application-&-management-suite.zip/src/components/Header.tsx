import React from 'react';
import { 
  ShoppingBag, 
  Shield, 
  Layers, 
  BarChart3, 
  CheckCircle2, 
  Award, 
  User as UserIcon, 
  LogOut, 
  Sparkles,
  ChevronDown,
  Terminal,
  FileCheck2,
  Lock
} from 'lucide-react';
import { User, UserRole } from '../types';

interface HeaderProps {
  activeTab: 'store' | 'crud' | 'analytics' | 'security' | 'testing' | 'certificate';
  setActiveTab: (tab: 'store' | 'crud' | 'analytics' | 'security' | 'testing' | 'certificate') => void;
  currentUser: User;
  onSwitchRole: (role: UserRole) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenAuth: () => void;
  onOpenTaskModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  onSwitchRole,
  cartCount,
  onOpenCart,
  onOpenAuth,
  onOpenTaskModal
}) => {
  const [roleDropdownOpen, setRoleDropdownOpen] = React.useState(false);

  const roles: { role: UserRole; label: string; desc: string; badgeColor: string }[] = [
    { role: 'admin', label: 'Admin (Full Access)', desc: 'CRUD + Security + Audit + Settings', badgeColor: 'bg-rose-50 text-rose-700 border-rose-200' },
    { role: 'manager', label: 'Manager (Inventory)', desc: 'Product CRUD + Order handling', badgeColor: 'bg-amber-50 text-amber-800 border-amber-200' },
    { role: 'customer', label: 'Customer (Darsini Gedda)', desc: 'Browse, Cart, Wishlist, Checkout', badgeColor: 'bg-indigo-50 text-indigo-700 border-indigo-200' },
    { role: 'guest', label: 'Guest (Public View)', desc: 'Read-only catalog explorer', badgeColor: 'bg-slate-100 text-slate-700 border-slate-200' },
  ];

  const currentRoleInfo = roles.find(r => r.role === currentUser.role) || roles[0];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top Announcement Bar */}
      <div className="bg-slate-900 px-4 py-1.5 border-b border-slate-800 text-xs text-slate-300 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-semibold border border-indigo-500/30 text-[11px]">
            <Sparkles className="w-3 h-3 text-indigo-400" />
            ApexPlanet Software Pvt Ltd
          </span>
          <span className="hidden sm:inline text-slate-600">|</span>
          <span className="hidden sm:inline font-medium text-slate-300">
            Task 5: Final Project and Certification (12 Days Timeline)
          </span>
        </div>

        <div className="flex items-center space-x-3">
          <button 
            onClick={onOpenTaskModal}
            id="view-task-rubric-btn"
            className="inline-flex items-center gap-1 text-indigo-400 hover:text-indigo-300 font-medium transition cursor-pointer"
          >
            <FileCheck2 className="w-3.5 h-3.5" />
            <span>Task Checklist & Rubric</span>
          </button>
          <span className="text-slate-700">|</span>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-[11px] text-slate-400">All Systems Operational</span>
          </div>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('store')}>
            <div className="w-10 h-10 rounded-xl bg-indigo-600 p-0.5 shadow-md shadow-indigo-600/20 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <span className="text-indigo-400 font-extrabold text-xl tracking-tight">▲</span>
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="text-lg font-bold text-slate-900 tracking-tight">ApexPlanet</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 font-mono font-bold">
                  PRO
                </span>
              </div>
              <p className="text-[10px] text-slate-500 tracking-wider uppercase font-medium">
                Enterprise Suite &bull; Task 5
              </p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1 bg-slate-100/80 p-1 rounded-xl border border-slate-200">
            <button
              id="nav-storefront-tab"
              onClick={() => setActiveTab('store')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === 'store'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Storefront</span>
            </button>

            <button
              id="nav-crud-tab"
              onClick={() => setActiveTab('crud')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === 'crud'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Products & CRUD</span>
            </button>

            <button
              id="nav-analytics-tab"
              onClick={() => setActiveTab('analytics')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === 'analytics'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Analytics</span>
            </button>

            <button
              id="nav-security-tab"
              onClick={() => setActiveTab('security')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === 'security'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Security & Audit</span>
            </button>

            <button
              id="nav-testing-tab"
              onClick={() => setActiveTab('testing')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === 'testing'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Test Suite</span>
            </button>

            <button
              id="nav-certificate-tab"
              onClick={() => setActiveTab('certificate')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === 'certificate'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-amber-800 hover:text-amber-900 hover:bg-amber-50'
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              <span>Certification</span>
            </button>
          </nav>

          {/* Right Action Icons & Role Switcher */}
          <div className="flex items-center space-x-3">
            {/* Cart Button */}
            <button
              id="open-cart-drawer-btn"
              onClick={onOpenCart}
              className="relative p-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 hover:text-slate-900 transition border border-slate-200 shadow-xs cursor-pointer"
              title="Shopping Cart"
            >
              <ShoppingBag className="w-5 h-5 text-indigo-600" />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 bg-indigo-600 text-white text-[11px] font-bold rounded-full flex items-center justify-center shadow-md shadow-indigo-600/30">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Quick RBAC Role Switcher */}
            <div className="relative">
              <button
                id="role-switcher-toggle-btn"
                onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
                className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 transition shadow-xs cursor-pointer"
              >
                <img 
                  src={currentUser.avatar} 
                  alt={currentUser.name} 
                  className="w-7 h-7 rounded-full object-cover ring-1 ring-indigo-500/40" 
                />
                <div className="text-left hidden sm:block">
                  <div className="flex items-center gap-1">
                    <span className="text-xs font-bold text-slate-900 max-w-[90px] truncate">{currentUser.name}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded border font-semibold ${currentRoleInfo.badgeColor}`}>
                      {currentUser.role.toUpperCase()}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 block">Switch Role</span>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {roleDropdownOpen && (
                <div 
                  className="absolute right-0 mt-2 w-72 bg-white border border-slate-200 rounded-2xl shadow-xl p-2 z-50 animate-in fade-in slide-in-from-top-2"
                  onMouseLeave={() => setRoleDropdownOpen(false)}
                >
                  <div className="px-3 py-2 border-b border-slate-100">
                    <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Role-Based Access Control</p>
                    <p className="text-xs text-slate-700 mt-0.5">Toggle live roles to test permissions & guards</p>
                  </div>

                  <div className="py-1 space-y-1">
                    {roles.map(r => (
                      <button
                        key={r.role}
                        id={`switch-role-${r.role}-btn`}
                        onClick={() => {
                          onSwitchRole(r.role);
                          setRoleDropdownOpen(false);
                        }}
                        className={`w-full text-left p-2 rounded-xl text-xs flex items-start gap-2.5 transition ${
                          currentUser.role === r.role 
                            ? 'bg-indigo-50 border border-indigo-200 text-indigo-900' 
                            : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                        }`}
                      >
                        <div className="mt-0.5">
                          {currentUser.role === r.role ? (
                            <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                          ) : (
                            <Lock className="w-4 h-4 text-slate-400" />
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-semibold">{r.label}</span>
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5">{r.desc}</p>
                        </div>
                      </button>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between px-2">
                    <button
                      onClick={() => {
                        setRoleDropdownOpen(false);
                        onOpenAuth();
                      }}
                      className="text-xs text-indigo-600 hover:text-indigo-700 flex items-center gap-1 font-medium py-1"
                    >
                      <UserIcon className="w-3.5 h-3.5" />
                      <span>Account Details</span>
                    </button>
                    <button
                      onClick={() => {
                        onSwitchRole('guest');
                        setRoleDropdownOpen(false);
                      }}
                      className="text-xs text-rose-600 hover:text-rose-700 flex items-center gap-1 font-medium py-1"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Tabs */}
      <div className="lg:hidden flex items-center justify-around bg-white border-t border-slate-200 px-2 py-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('store')}
          className={`flex flex-col items-center gap-1 px-2 py-1 text-[11px] font-medium rounded-lg ${
            activeTab === 'store' ? 'text-indigo-600 font-bold' : 'text-slate-500'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Shop</span>
        </button>

        <button
          onClick={() => setActiveTab('crud')}
          className={`flex flex-col items-center gap-1 px-2 py-1 text-[11px] font-medium rounded-lg ${
            activeTab === 'crud' ? 'text-indigo-600 font-bold' : 'text-slate-500'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>CRUD</span>
        </button>

        <button
          onClick={() => setActiveTab('analytics')}
          className={`flex flex-col items-center gap-1 px-2 py-1 text-[11px] font-medium rounded-lg ${
            activeTab === 'analytics' ? 'text-indigo-600 font-bold' : 'text-slate-500'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Stats</span>
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`flex flex-col items-center gap-1 px-2 py-1 text-[11px] font-medium rounded-lg ${
            activeTab === 'security' ? 'text-indigo-600 font-bold' : 'text-slate-500'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>Security</span>
        </button>

        <button
          onClick={() => setActiveTab('testing')}
          className={`flex flex-col items-center gap-1 px-2 py-1 text-[11px] font-medium rounded-lg ${
            activeTab === 'testing' ? 'text-indigo-600 font-bold' : 'text-slate-500'
          }`}
        >
          <Terminal className="w-4 h-4" />
          <span>Tests</span>
        </button>

        <button
          onClick={() => setActiveTab('certificate')}
          className={`flex flex-col items-center gap-1 px-2 py-1 text-[11px] font-medium rounded-lg ${
            activeTab === 'certificate' ? 'text-amber-600 font-bold' : 'text-amber-700/70'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>Cert</span>
        </button>
      </div>
    </header>
  );
};
