import React, { useState } from 'react';
import { 
  Shield, 
  Lock, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Terminal, 
  Download, 
  Search, 
  RefreshCw,
  Key,
  ShieldCheck,
  Code,
  Activity,
  Sliders
} from 'lucide-react';
import { AuditLog, SecuritySettings, UserRole } from '../types';
import { exportToCSV, sanitizeInput } from '../utils/security';

interface SecurityAuditViewProps {
  auditLogs: AuditLog[];
  securitySettings: SecuritySettings;
  onUpdateSecuritySettings: (settings: SecuritySettings, updatedSettingName: string) => void;
  currentUserRole: UserRole;
  onClearLogs: () => void;
}

export const SecurityAuditView: React.FC<SecurityAuditViewProps> = ({
  auditLogs,
  securitySettings,
  onUpdateSecuritySettings,
  currentUserRole,
  onClearLogs
}) => {
  const [logFilter, setLogFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [testPayload, setTestPayload] = useState('<script>alert("Apex XSS Injection Test")</script>');

  const filteredLogs = auditLogs.filter(log => {
    if (logFilter.trim()) {
      const q = logFilter.toLowerCase();
      const matchActor = log.actor.toLowerCase().includes(q);
      const matchAction = log.action.toLowerCase().includes(q);
      const matchTarget = log.target.toLowerCase().includes(q);
      const matchDetails = log.details.toLowerCase().includes(q);
      if (!matchActor && !matchAction && !matchTarget && !matchDetails) return false;
    }
    if (statusFilter !== 'All' && log.status !== statusFilter) {
      return false;
    }
    return true;
  });

  const handleExportLogs = () => {
    exportToCSV('ApexPlanet_Security_Audit_Logs', auditLogs);
  };

  const handleToggle = (key: keyof SecuritySettings, label: string) => {
    const updated = {
      ...securitySettings,
      [key]: !securitySettings[key]
    };
    onUpdateSecuritySettings(updated, label);
  };

  const permissionsMatrix: { feature: string; admin: boolean; manager: boolean; customer: boolean; guest: boolean }[] = [
    { feature: 'View Product Catalog & Search', admin: true, manager: true, customer: true, guest: true },
    { feature: 'Add to Cart & Checkout Simulator', admin: true, manager: true, customer: true, guest: false },
    { feature: 'Create New Products & Upload', admin: true, manager: true, customer: false, guest: false },
    { feature: 'Edit Products & Stock Pricing', admin: true, manager: true, customer: false, guest: false },
    { feature: 'Delete Products & Bulk Purge', admin: true, manager: false, customer: false, guest: false },
    { feature: 'Manage Security Policies & WAF', admin: true, manager: false, customer: false, guest: false },
    { feature: 'Execute Automated Test Suite', admin: true, manager: true, customer: false, guest: false },
    { feature: 'Generate Internship Certification', admin: true, manager: true, customer: true, guest: true }
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-indigo-600" />
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                Security Architecture & Real-Time Audit Engine
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Implements Role-Based Access Control (RBAC), XSS sanitization layers, tamper-evident audit trails, and policy enforcement.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs px-3 py-1 rounded-xl bg-indigo-50 text-indigo-700 border border-indigo-200 font-mono font-bold">
              TLS 1.3 &bull; AES-256
            </span>
          </div>
        </div>
      </div>

      {/* Grid: RBAC Matrix + Security Settings */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* RBAC Permissions Matrix */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900">RBAC Role Permissions Matrix</h3>
            </div>
            <span className="text-[11px] text-slate-500 font-medium">Active Role: <strong className="text-indigo-600 uppercase">{currentUserRole}</strong></span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500">
                  <th className="p-2.5 font-semibold">Capability / Operation</th>
                  <th className="p-2.5 text-center font-bold text-rose-700">Admin</th>
                  <th className="p-2.5 text-center font-bold text-amber-700">Manager</th>
                  <th className="p-2.5 text-center font-bold text-emerald-700">Customer</th>
                  <th className="p-2.5 text-center font-bold text-slate-500">Guest</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {permissionsMatrix.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="p-2.5 font-medium text-slate-800">{item.feature}</td>
                    <td className="p-2.5 text-center">
                      {item.admin ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" />
                      ) : (
                        <XCircle className="w-4 h-4 text-slate-300 mx-auto" />
                      )}
                    </td>
                    <td className="p-2.5 text-center">
                      {item.manager ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" />
                      ) : (
                        <XCircle className="w-4 h-4 text-slate-300 mx-auto" />
                      )}
                    </td>
                    <td className="p-2.5 text-center">
                      {item.customer ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" />
                      ) : (
                        <XCircle className="w-4 h-4 text-slate-300 mx-auto" />
                      )}
                    </td>
                    <td className="p-2.5 text-center">
                      {item.guest ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" />
                      ) : (
                        <XCircle className="w-4 h-4 text-slate-300 mx-auto" />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Security Controls & XSS Tester */}
        <div className="space-y-4">
          {/* Security Guard Toggles */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
              <Sliders className="w-4 h-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900">Security Guards</h3>
            </div>

            <div className="space-y-2.5 text-xs">
              <label className="flex items-center justify-between cursor-pointer">
                <div>
                  <span className="font-semibold text-slate-800 block">Strict XSS Sanitization</span>
                  <span className="text-[10px] text-slate-500">Escapes HTML & blocks script injection</span>
                </div>
                <input
                  type="checkbox"
                  checked={securitySettings.xssSanitizationStrict}
                  onChange={() => handleToggle('xssSanitizationStrict', 'XSS Sanitization')}
                  className="w-4 h-4 accent-indigo-600 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between cursor-pointer pt-2 border-t border-slate-100">
                <div>
                  <span className="font-semibold text-slate-800 block">Rate Limiting Protection</span>
                  <span className="text-[10px] text-slate-500">Restricts burst requests per IP</span>
                </div>
                <input
                  type="checkbox"
                  checked={securitySettings.rateLimitingEnabled}
                  onChange={() => handleToggle('rateLimitingEnabled', 'Rate Limiting')}
                  className="w-4 h-4 accent-indigo-600 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between cursor-pointer pt-2 border-t border-slate-100">
                <div>
                  <span className="font-semibold text-slate-800 block">SQL Injection Shield</span>
                  <span className="text-[10px] text-slate-500">Enforces parameterized query schemas</span>
                </div>
                <input
                  type="checkbox"
                  checked={securitySettings.sqlInjectionShield}
                  onChange={() => handleToggle('sqlInjectionShield', 'SQL Injection Shield')}
                  className="w-4 h-4 accent-indigo-600 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between cursor-pointer pt-2 border-t border-slate-100">
                <div>
                  <span className="font-semibold text-slate-800 block">Audit Logging Active</span>
                  <span className="text-[10px] text-slate-500">Records actor, IP & mutation logs</span>
                </div>
                <input
                  type="checkbox"
                  checked={securitySettings.auditLoggingEnabled}
                  onChange={() => handleToggle('auditLoggingEnabled', 'Audit Logging')}
                  className="w-4 h-4 accent-indigo-600 cursor-pointer"
                />
              </label>
            </div>
          </div>

          {/* Interactive XSS Sanitization Sandbox */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
              <Code className="w-4 h-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900">XSS Sanitizer Live Tester</h3>
            </div>

            <div className="space-y-2 text-xs">
              <label className="block text-[11px] font-semibold text-slate-600">Raw Input Payload</label>
              <input
                type="text"
                value={testPayload}
                onChange={e => setTestPayload(e.target.value)}
                className="w-full font-mono text-[11px] bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-rose-600 focus:outline-none focus:bg-white focus:border-indigo-600"
              />

              <label className="block text-[11px] font-semibold text-slate-600 pt-1">Sanitized Clean Output</label>
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 font-mono text-[11px] text-emerald-700 break-all">
                {sanitizeInput(testPayload) || '<empty>'}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Audit Trail Section */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-indigo-600" />
            <div>
              <h3 className="text-base font-bold text-slate-900">Real-Time Security Audit Trail</h3>
              <p className="text-xs text-slate-500">Tracks mutations, logins, and security events</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={logFilter}
                onChange={e => setLogFilter(e.target.value)}
                placeholder="Search audit trail..."
                className="bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-indigo-600"
              />
            </div>

            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-700 focus:outline-none focus:bg-white focus:border-indigo-600 cursor-pointer"
            >
              <option value="All">All Statuses</option>
              <option value="SUCCESS">SUCCESS</option>
              <option value="WARNING">WARNING</option>
              <option value="DENIED">DENIED</option>
            </select>

            <button
              onClick={handleExportLogs}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 hover:bg-slate-100 text-xs font-semibold text-slate-700 transition cursor-pointer"
              title="Download Log Report"
            >
              <Download className="w-3.5 h-3.5 text-indigo-600" />
              <span>Export</span>
            </button>
          </div>
        </div>

        {/* Audit Log Table */}
        <div className="overflow-x-auto rounded-xl border border-slate-200">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-semibold text-[11px]">
                <th className="p-3">Timestamp</th>
                <th className="p-3">Action Event</th>
                <th className="p-3">Actor & Role</th>
                <th className="p-3">Target</th>
                <th className="p-3">Details</th>
                <th className="p-3">IP Address</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-6 text-center text-slate-400 font-sans">
                    No matching audit records found
                  </td>
                </tr>
              ) : (
                filteredLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50 transition">
                    <td className="p-3 text-slate-500 whitespace-nowrap">{log.timestamp}</td>
                    <td className="p-3 font-semibold text-indigo-600 whitespace-nowrap">{log.action}</td>
                    <td className="p-3 text-slate-700 whitespace-nowrap">
                      <span className="text-slate-900 font-bold">{log.actor}</span>
                      <span className="text-[10px] text-slate-500 ml-1">({log.actorRole})</span>
                    </td>
                    <td className="p-3 text-indigo-700 font-semibold">{log.target}</td>
                    <td className="p-3 text-slate-600 font-sans text-xs max-w-xs">{log.details}</td>
                    <td className="p-3 text-slate-500">{log.ipAddress}</td>
                    <td className="p-3 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        log.status === 'SUCCESS' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                        log.status === 'WARNING' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                        'bg-rose-50 text-rose-700 border border-rose-200'
                      }`}>
                        {log.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
