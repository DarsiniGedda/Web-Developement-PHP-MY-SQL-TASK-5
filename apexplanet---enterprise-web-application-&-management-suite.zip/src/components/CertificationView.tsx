import React, { useState } from 'react';
import { 
  Award, 
  Download, 
  Sparkles, 
  CheckCircle2, 
  Printer, 
  Share2, 
  QrCode, 
  ShieldCheck,
  Edit3,
  Calendar,
  Building2,
  UserCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { InternshipCertificateData } from '../types';

interface CertificationViewProps {
  initialData: InternshipCertificateData;
}

export const CertificationView: React.FC<CertificationViewProps> = ({
  initialData
}) => {
  const [certData, setCertData] = useState<InternshipCertificateData>(initialData);
  const [isEditing, setIsEditing] = useState(false);

  const handleTriggerCelebration = () => {
    try {
      confetti({
        particleCount: 120,
        spread: 100,
        origin: { y: 0.6 }
      });
    } catch {
      // safe fallback
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header Controls Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs print:hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Award className="w-6 h-6 text-indigo-600" />
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                ApexPlanet Software Pvt Ltd &bull; Official Project Certification
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Final deliverable for Task 5: 12-Day Full-Stack Web Development Internship Sprint.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 hover:bg-slate-100 text-xs font-semibold text-slate-700 transition cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5 text-indigo-600" />
              <span>{isEditing ? 'Done Editing' : 'Customize Name/Details'}</span>
            </button>

            <button
              onClick={handleTriggerCelebration}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold transition shadow-xs cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Celebrate! 🎉</span>
            </button>

            <button
              onClick={handlePrint}
              id="print-certificate-btn"
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition shadow-xs cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save PDF</span>
            </button>
          </div>
        </div>

        {/* Customization Drawer when editing */}
        {isEditing && (
          <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs animate-in fade-in">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Student / Candidate Name</label>
              <input
                type="text"
                value={certData.studentName}
                onChange={e => setCertData({ ...certData, studentName: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-slate-900 focus:outline-none focus:bg-white focus:border-indigo-600"
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Intern ID</label>
              <input
                type="text"
                value={certData.internId}
                onChange={e => setCertData({ ...certData, internId: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-slate-900 focus:outline-none focus:bg-white focus:border-indigo-600"
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Completion Date</label>
              <input
                type="text"
                value={certData.completionDate}
                onChange={e => setCertData({ ...certData, completionDate: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-slate-900 focus:outline-none focus:bg-white focus:border-indigo-600"
              />
            </div>
          </div>
        )}
      </div>

      {/* The Certificate Canvas */}
      <div className="max-w-4xl mx-auto bg-gradient-to-b from-stone-50 via-amber-50/40 to-stone-100 text-slate-900 rounded-3xl p-8 sm:p-12 shadow-2xl border-[12px] border-amber-600/30 relative overflow-hidden print:border-none print:shadow-none print:p-6 print:m-0">
        {/* Subtle Watermark */}
        <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none select-none">
          <span className="text-[320px] font-black text-amber-900">APEX</span>
        </div>

        {/* Inner Border Frame */}
        <div className="border-2 border-dashed border-amber-700/40 rounded-2xl p-6 sm:p-10 relative z-10 space-y-6">
          {/* Certificate Header */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-amber-300/80 pb-6 text-center sm:text-left">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-800 p-0.5 shadow-md flex items-center justify-center">
                <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                  <span className="text-emerald-400 font-black text-2xl">▲</span>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-extrabold text-slate-900 tracking-tight">
                  {certData.companyName}
                </h3>
                <p className="text-xs text-amber-800 font-semibold tracking-wider uppercase">
                  Excellence in Software Engineering & Product Delivery
                </p>
              </div>
            </div>

            <div className="text-center sm:text-right">
              <span className="text-[11px] font-mono font-bold text-amber-900 bg-amber-100 px-3 py-1 rounded-full border border-amber-300">
                CERTIFICATE ID: {certData.certificateId}
              </span>
              <p className="text-[10px] text-slate-500 mt-1">
                Verified Blockchain Hash: {certData.verificationCode}
              </p>
            </div>
          </div>

          {/* Title */}
          <div className="text-center space-y-2 py-2">
            <span className="text-xs font-bold uppercase tracking-[0.25em] text-amber-800">
              Certificate of Completion & Distinction
            </span>
            <h1 
              style={{ fontFamily: 'Cinzel, serif' }} 
              className="text-2xl sm:text-4xl font-black text-slate-900 tracking-wide uppercase"
            >
              Final Project & Task 5 Certification
            </h1>
            <p className="text-xs text-slate-600 max-w-lg mx-auto italic">
              This is to certify the successful completion of the 12-Day Full-Stack Web Development Internship Sprint
            </p>
          </div>

          {/* Student Recipient Name */}
          <div className="text-center py-3 border-y border-amber-200/80">
            <p className="text-xs font-medium text-slate-500 uppercase tracking-widest">Proudly Presented To</p>
            <h2 
              style={{ fontFamily: 'Plus Jakarta Sans, sans-serif' }}
              className="text-3xl sm:text-4xl font-black text-emerald-950 mt-1 tracking-tight"
            >
              {certData.studentName}
            </h2>
            <div className="inline-flex items-center gap-2 mt-2 px-3 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold border border-emerald-300">
              <UserCheck className="w-3.5 h-3.5 text-emerald-700" />
              <span>Intern ID: {certData.internId} &bull; {certData.domain}</span>
            </div>
          </div>

          {/* Description of Achievement */}
          <div className="text-xs text-slate-700 leading-relaxed text-center max-w-2xl mx-auto space-y-2">
            <p>
              For outstanding performance and successful delivery of <strong>Task 5: Final Integrated Web Application</strong>, incorporating comprehensive <strong>CRUD Operations, Full-Text Real-Time Search, Multi-Facet Filtering, Dynamic Pagination, Role-Based Access Control (RBAC), Security Audit Logging, and Automated Quality Testing</strong>.
            </p>
          </div>

          {/* Key Competencies Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-[11px] font-semibold text-slate-800">
            <div className="bg-amber-100/70 border border-amber-300/80 rounded-xl p-2.5 text-center">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto mb-1" />
              <span>CRUD Architecture</span>
            </div>
            <div className="bg-amber-100/70 border border-amber-300/80 rounded-xl p-2.5 text-center">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto mb-1" />
              <span>Search & Pagination</span>
            </div>
            <div className="bg-amber-100/70 border border-amber-300/80 rounded-xl p-2.5 text-center">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto mb-1" />
              <span>Security & RBAC</span>
            </div>
            <div className="bg-amber-100/70 border border-amber-300/80 rounded-xl p-2.5 text-center">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto mb-1" />
              <span>Testing & Debugging</span>
            </div>
          </div>

          {/* Signatures & Seal */}
          <div className="pt-6 border-t border-amber-300/80 grid grid-cols-3 gap-4 items-center text-center">
            {/* Mentor Signature */}
            <div>
              <div 
                style={{ fontFamily: 'Great Vibes, cursive' }} 
                className="text-2xl text-slate-800 font-bold"
              >
                Rajesh Verma
              </div>
              <div className="h-0.5 w-28 bg-slate-400 mx-auto my-1"></div>
              <p className="text-[11px] font-bold text-slate-900">{certData.mentorName}</p>
              <p className="text-[10px] text-slate-500">Lead Technical Architect</p>
            </div>

            {/* Official Gold Seal */}
            <div className="flex flex-col items-center justify-center">
              <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-500 via-amber-300 to-amber-600 p-1 shadow-lg shadow-amber-500/30 flex items-center justify-center">
                <div className="w-full h-full rounded-full border-2 border-amber-800/40 bg-amber-400 flex flex-col items-center justify-center text-slate-950">
                  <Award className="w-6 h-6 text-amber-950" />
                  <span className="text-[8px] font-black uppercase tracking-tighter">VERIFIED</span>
                </div>
              </div>
              <span className="text-[10px] font-bold text-amber-900 mt-1">{certData.grade}</span>
            </div>

            {/* Director Signature */}
            <div>
              <div 
                style={{ fontFamily: 'Great Vibes, cursive' }} 
                className="text-2xl text-slate-800 font-bold"
              >
                K. V. Ramana
              </div>
              <div className="h-0.5 w-28 bg-slate-400 mx-auto my-1"></div>
              <p className="text-[11px] font-bold text-slate-900">K. V. Ramana, CEO</p>
              <p className="text-[10px] text-slate-500">{certData.companyName}</p>
            </div>
          </div>

          {/* Issue Date & Verification */}
          <div className="flex items-center justify-between text-[10px] text-slate-500 pt-2 border-t border-amber-200">
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3 text-amber-700" />
              <span>Date of Issue: <strong>{certData.completionDate}</strong></span>
            </span>
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-600" />
              <span>Tamper-Proof Digital Credential</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
