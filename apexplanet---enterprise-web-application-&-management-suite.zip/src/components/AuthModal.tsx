import React, { useState } from 'react';
import { X, Lock, Mail, User as UserIcon, Shield, CheckCircle2, Key, LogIn, Sparkles } from 'lucide-react';
import { User, UserRole } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onLoginAsUser: (user: User) => void;
  availableUsers: User[];
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onLoginAsUser,
  availableUsers
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'quick-switch' | 'token'>('quick-switch');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl space-y-4">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600 border border-indigo-200">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Authentication & RBAC Identity</h2>
              <p className="text-xs text-slate-500">Manage user profile, active tokens & role switching</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-900 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="px-6 flex items-center gap-2 border-b border-slate-100 pb-3 text-xs">
          <button
            onClick={() => setActiveTab('quick-switch')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition cursor-pointer ${
              activeTab === 'quick-switch'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 hover:text-slate-900 bg-slate-100'
            }`}
          >
            Switch User Identity
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition cursor-pointer ${
              activeTab === 'profile'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 hover:text-slate-900 bg-slate-100'
            }`}
          >
            Active Profile
          </button>
          <button
            onClick={() => setActiveTab('token')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition cursor-pointer ${
              activeTab === 'token'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 hover:text-slate-900 bg-slate-100'
            }`}
          >
            JWT Bearer Token
          </button>
        </div>

        {/* Content */}
        <div className="p-6 pt-0">
          {activeTab === 'quick-switch' ? (
            <div className="space-y-3">
              <p className="text-xs text-slate-600">
                Select an identity to test how the UI adapts and protects data per role:
              </p>

              <div className="space-y-2">
                {availableUsers.map(user => {
                  const isCurrent = currentUser.id === user.id;

                  return (
                    <div
                      key={user.id}
                      onClick={() => {
                        onLoginAsUser(user);
                        onClose();
                      }}
                      className={`p-3 rounded-2xl border transition flex items-center justify-between cursor-pointer ${
                        isCurrent
                          ? 'bg-indigo-50/70 border-indigo-300'
                          : 'bg-slate-50 border-slate-200 hover:border-slate-300 hover:bg-slate-100/70'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={user.avatar}
                          alt={user.name}
                          className="w-10 h-10 rounded-full object-cover ring-2 ring-slate-200"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 text-xs">{user.name}</span>
                            <span className={`text-[10px] px-2 py-0.2 rounded-full font-bold uppercase ${
                              user.role === 'admin' ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                              user.role === 'manager' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                              user.role === 'customer' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                              'bg-slate-100 text-slate-700 border border-slate-200'
                            }`}>
                              {user.role}
                            </span>
                          </div>
                          <span className="text-[11px] text-slate-500 block">{user.email} &bull; {user.department}</span>
                        </div>
                      </div>

                      {isCurrent ? (
                        <CheckCircle2 className="w-5 h-5 text-indigo-600" />
                      ) : (
                        <span className="text-xs text-slate-500 hover:text-indigo-600 font-medium">
                          Select &rarr;
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ) : activeTab === 'profile' ? (
            <div className="space-y-4 text-xs">
              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-14 h-14 rounded-2xl object-cover ring-2 ring-indigo-200"
                />
                <div>
                  <h3 className="text-sm font-bold text-slate-900">{currentUser.name}</h3>
                  <p className="text-slate-500">{currentUser.email}</p>
                  <span className="inline-block mt-1 text-[10px] px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-bold uppercase border border-indigo-200">
                    ROLE: {currentUser.role}
                  </span>
                </div>
              </div>

              <div className="space-y-2 text-slate-600">
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Department:</span>
                  <span className="font-semibold text-slate-900">{currentUser.department || 'N/A'}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Session Status:</span>
                  <span className="text-emerald-700 font-semibold">Active (Authenticated)</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-slate-500">Last Verified Login:</span>
                  <span className="font-mono text-slate-700">{currentUser.lastLogin}</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-3 text-xs">
              <p className="text-slate-500">
                Simulated JSON Web Token (JWT) issued by ApexPlanet Auth Server with role claim:
              </p>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 font-mono text-[11px] text-indigo-700 break-all leading-relaxed">
                {currentUser.token || 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNjg0OTI4MSIsIm5hbWUiOiJBcGV4VXNlciIsInJvbGUiOiJjdXN0b21lciIsImlhdCI6MTc1Njg0OTI4MH0.sig_apex_key'}
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-slate-500 text-[11px]">
                Algorithm: HS256 &bull; Issuer: auth.apexplanet.com &bull; Subject: {currentUser.email}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
