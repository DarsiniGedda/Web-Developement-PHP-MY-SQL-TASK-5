import React from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  DollarSign, 
  Package, 
  AlertTriangle, 
  Star, 
  Layers, 
  ShoppingBag,
  ArrowUpRight,
  ShieldCheck
} from 'lucide-react';
import { Product, Order } from '../types';

interface AnalyticsDashboardProps {
  products: Product[];
  orders: Order[];
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  products,
  orders
}) => {
  // Compute Key Metrics
  const totalCatalogValue = products.reduce((sum, p) => sum + p.price * p.stock, 0);
  const totalUnitsInStock = products.reduce((sum, p) => sum + p.stock, 0);
  const lowStockCount = products.filter(p => p.stock > 0 && p.stock <= 10).length;
  const outOfStockCount = products.filter(p => p.stock === 0).length;
  const avgRating = products.length 
    ? (products.reduce((sum, p) => sum + p.rating, 0) / products.length).toFixed(1)
    : '0';

  const totalOrderRevenue = orders.reduce((sum, o) => sum + o.total, 0);

  // Category Breakdown
  const categoryStats = products.reduce((acc, p) => {
    acc[p.category] = (acc[p.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <BarChart3 className="w-6 h-6 text-indigo-600" />
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                Enterprise Analytics & Inventory Intelligence
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Live operational metrics, catalog asset valuation, inventory distribution, and order tracking telemetry.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs px-3 py-1 rounded-xl bg-indigo-50 text-indigo-700 border border-indigo-200 font-mono font-bold">
              Real-Time Sync Active
            </span>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Inventory Value</span>
            <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900">
            ${totalCatalogValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="flex items-center gap-1 text-[11px] text-emerald-700 font-medium">
            <TrendingUp className="w-3 h-3" />
            <span>Across {totalUnitsInStock} total units</span>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Active SKUs</span>
            <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900">{products.length} Items</div>
          <div className="flex items-center gap-1 text-[11px] text-indigo-600 font-medium">
            <span>5 product categories</span>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Stock Alerts</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-700">{lowStockCount + outOfStockCount} SKUs</div>
          <div className="flex items-center gap-2 text-[11px] text-slate-500">
            <span className="text-amber-700 font-medium">{lowStockCount} low</span>
            <span>&bull;</span>
            <span className="text-rose-600 font-medium">{outOfStockCount} out of stock</span>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Customer Rating</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <Star className="w-4 h-4 fill-current" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900">{avgRating} / 5.0</div>
          <div className="flex items-center gap-1 text-[11px] text-emerald-700 font-medium">
            <span>99.2% satisfaction rate</span>
          </div>
        </div>
      </div>

      {/* Breakdown Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Breakdown */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900">Category Distribution</h3>
            <span className="text-xs text-slate-500">{products.length} Products</span>
          </div>

          <div className="space-y-3">
            {Object.entries(categoryStats).map(([cat, count]) => {
              const numCount = Number(count);
              const percentage = products.length ? Math.round((numCount / products.length) * 100) : 0;
              return (
                <div key={cat} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-700">{cat}</span>
                    <span className="text-slate-500">{numCount} items ({percentage}%)</span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full bg-indigo-600"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Orders & Activity */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900">Recent Orders ({orders.length})</h3>
            <span className="text-xs text-indigo-600 font-bold">
              ${totalOrderRevenue.toFixed(2)} Revenue
            </span>
          </div>

          {orders.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs space-y-2">
              <ShoppingBag className="w-8 h-8 mx-auto text-slate-300" />
              <p>No orders placed in this session yet.</p>
              <p className="text-[11px] text-slate-400">Go to Storefront, add products to cart, and checkout!</p>
            </div>
          ) : (
            <div className="space-y-3 overflow-y-auto max-h-60">
              {orders.map(order => (
                <div key={order.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-slate-900 flex items-center gap-1.5">
                      <span>{order.id}</span>
                      <span className="text-[10px] px-2 py-0.2 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                        {order.status}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {order.customerName} &bull; {order.items.length} items
                    </p>
                  </div>
                  <div className="text-right font-bold text-indigo-600">
                    ${order.total.toFixed(2)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
