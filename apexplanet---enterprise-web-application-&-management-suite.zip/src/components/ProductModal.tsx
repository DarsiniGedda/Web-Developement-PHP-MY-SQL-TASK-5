import React, { useState, useEffect } from 'react';
import { X, Sparkles, Image as ImageIcon, Plus, Trash2, Check, AlertTriangle } from 'lucide-react';
import { Product, ProductCategory } from '../types';
import { sanitizeInput, isValidSKU } from '../utils/security';

interface ProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (productData: Partial<Product>) => void;
  initialProduct?: Product | null;
}

const CATEGORIES: ProductCategory[] = [
  'Footwear',
  'Apparel',
  'Accessories',
  'Electronics',
  'Office & Tech'
];

const SAMPLE_IMAGES = [
  { label: 'Running Shoes', url: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80' },
  { label: 'Tech Jacket', url: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&auto=format&fit=crop&q=80' },
  { label: 'Cyber Backpack', url: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&auto=format&fit=crop&q=80' },
  { label: 'Studio Headphones', url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80' },
  { label: 'Mech Keyboard', url: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&auto=format&fit=crop&q=80' },
  { label: 'Smart Watch', url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80' }
];

export const ProductModal: React.FC<ProductModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialProduct
}) => {
  const isEditing = !!initialProduct;

  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [category, setCategory] = useState<ProductCategory>('Footwear');
  const [price, setPrice] = useState<string>('');
  const [originalPrice, setOriginalPrice] = useState<string>('');
  const [stock, setStock] = useState<string>('15');
  const [brand, setBrand] = useState('Apex Gear');
  const [badge, setBadge] = useState<string>('New');
  const [imageUrl, setImageUrl] = useState('');
  const [description, setDescription] = useState('');
  const [tagsInput, setTagsInput] = useState('');
  const [specs, setSpecs] = useState<{ key: string; value: string }[]>([
    { key: 'Material', value: 'Aerospace Grade' },
    { key: 'Warranty', value: '2-Year Apex Warranty' }
  ]);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (initialProduct) {
      setName(initialProduct.name);
      setSku(initialProduct.sku);
      setCategory(initialProduct.category);
      setPrice(initialProduct.price.toString());
      setOriginalPrice(initialProduct.originalPrice ? initialProduct.originalPrice.toString() : '');
      setStock(initialProduct.stock.toString());
      setBrand(initialProduct.brand);
      setBadge(initialProduct.badge || '');
      setImageUrl(initialProduct.imageUrl);
      setDescription(initialProduct.description);
      setTagsInput(initialProduct.tags.join(', '));
      if (initialProduct.specs) {
        setSpecs(Object.entries(initialProduct.specs).map(([key, value]) => ({ key, value })));
      }
    } else {
      // Reset defaults for Create mode
      const randomSkuNum = Math.floor(Math.random() * 900 + 100);
      setName('');
      setSku(`APX-PRD-${randomSkuNum}`);
      setCategory('Footwear');
      setPrice('');
      setOriginalPrice('');
      setStock('20');
      setBrand('Apex Athletics');
      setBadge('New');
      setImageUrl(SAMPLE_IMAGES[0].url);
      setDescription('');
      setTagsInput('Premium, High-Performance, Apex');
      setSpecs([
        { key: 'Material', value: 'Engineered Polymer' },
        { key: 'Warranty', value: '1-Year Limited' }
      ]);
    }
    setErrors({});
  }, [initialProduct, isOpen]);

  if (!isOpen) return null;

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!name.trim()) newErrors.name = 'Product name is required';
    if (!sku.trim()) newErrors.sku = 'SKU is required';
    else if (!isValidSKU(sku)) newErrors.sku = 'Format must be XXX-XXX-XXX (e.g. APX-APP-001)';
    
    const parsedPrice = parseFloat(price);
    if (isNaN(parsedPrice) || parsedPrice <= 0) {
      newErrors.price = 'Price must be a valid positive number';
    }

    const parsedStock = parseInt(stock, 10);
    if (isNaN(parsedStock) || parsedStock < 0) {
      newErrors.stock = 'Stock must be 0 or greater';
    }

    if (!imageUrl.trim()) newErrors.imageUrl = 'Image URL is required';
    if (!description.trim()) newErrors.description = 'Description is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    const parsedPrice = parseFloat(price);
    const parsedStock = parseInt(stock, 10);
    const parsedOriginalPrice = originalPrice ? parseFloat(originalPrice) : undefined;

    // Convert specs array to object
    const specsObject: Record<string, string> = {};
    specs.forEach(s => {
      if (s.key.trim() && s.value.trim()) {
        specsObject[sanitizeInput(s.key)] = sanitizeInput(s.value);
      }
    });

    const parsedTags = tagsInput
      .split(',')
      .map(t => sanitizeInput(t.trim()))
      .filter(Boolean);

    const productPayload: Partial<Product> = {
      name: sanitizeInput(name),
      sku: sanitizeInput(sku).toUpperCase(),
      category,
      price: parsedPrice,
      originalPrice: parsedOriginalPrice,
      stock: parsedStock,
      status: parsedStock === 0 ? 'Out of Stock' : parsedStock <= 10 ? 'Low Stock' : 'In Stock',
      brand: sanitizeInput(brand),
      badge: badge ? (badge as any) : undefined,
      imageUrl: sanitizeInput(imageUrl),
      description: sanitizeInput(description),
      tags: parsedTags.length ? parsedTags : ['General'],
      specs: specsObject
    };

    onSave(productPayload);
  };

  const handleAddSpec = () => {
    setSpecs(prev => [...prev, { key: '', value: '' }]);
  };

  const handleRemoveSpec = (index: number) => {
    setSpecs(prev => prev.filter((_, i) => i !== index));
  };

  const handleSpecChange = (index: number, field: 'key' | 'value', val: string) => {
    setSpecs(prev => prev.map((s, i) => i === index ? { ...s, [field]: val } : s));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto animate-in fade-in">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-6">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-700 border border-indigo-200 flex items-center justify-center font-bold text-sm">
              {isEditing ? '✏️' : '✨'}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {isEditing ? 'Edit Product Record' : 'Create New Product'}
              </h2>
              <p className="text-xs text-slate-500">
                {isEditing ? `Updating SKU: ${initialProduct?.sku}` : 'Fill in the required fields and validate data'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-900 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body Form */}
        <form onSubmit={handleFormSubmit} className="p-6 overflow-y-auto space-y-4 flex-1 text-xs">
          {/* Row 1: Name and SKU */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1.5">
                Product Name <span className="text-rose-600">*</span>
              </label>
              <input
                id="product-form-name"
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Apex HyperLight Running Shoes"
                className={`w-full bg-slate-50 border rounded-xl px-3.5 py-2 text-slate-900 placeholder-slate-400 focus:outline-none focus:bg-white ${
                  errors.name ? 'border-rose-500 ring-1 ring-rose-500' : 'border-slate-200 focus:border-indigo-600'
                }`}
              />
              {errors.name && <p className="text-rose-600 text-[11px] mt-1">{errors.name}</p>}
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">
                SKU Code <span className="text-rose-600">*</span>
              </label>
              <input
                id="product-form-sku"
                type="text"
                value={sku}
                onChange={e => setSku(e.target.value)}
                placeholder="APX-CAT-001"
                className={`w-full font-mono bg-slate-50 border rounded-xl px-3.5 py-2 text-indigo-700 font-bold placeholder-slate-400 uppercase focus:outline-none focus:bg-white ${
                  errors.sku ? 'border-rose-500 ring-1 ring-rose-500' : 'border-slate-200 focus:border-indigo-600'
                }`}
              />
              {errors.sku && <p className="text-rose-600 text-[11px] mt-1">{errors.sku}</p>}
            </div>
          </div>

          {/* Row 2: Category, Brand, Badge */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">Category</label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as ProductCategory)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 focus:outline-none focus:bg-white focus:border-indigo-600 cursor-pointer"
              >
                {CATEGORIES.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">Brand</label>
              <input
                type="text"
                value={brand}
                onChange={e => setBrand(e.target.value)}
                placeholder="Apex Athletics"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 focus:outline-none focus:bg-white focus:border-indigo-600"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">Promotional Badge</label>
              <select
                value={badge}
                onChange={e => setBadge(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 focus:outline-none focus:bg-white focus:border-indigo-600 cursor-pointer"
              >
                <option value="">None</option>
                <option value="New">New Release</option>
                <option value="Hot">Hot Item</option>
                <option value="Sale">On Sale</option>
                <option value="Featured">Featured Pick</option>
              </select>
            </div>
          </div>

          {/* Row 3: Price, Original Price, Stock */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">
                Current Price ($) <span className="text-rose-600">*</span>
              </label>
              <input
                id="product-form-price"
                type="number"
                step="0.01"
                min="0.01"
                value={price}
                onChange={e => setPrice(e.target.value)}
                placeholder="149.99"
                className={`w-full bg-slate-50 border rounded-xl px-3.5 py-2 text-slate-900 focus:outline-none focus:bg-white ${
                  errors.price ? 'border-rose-500' : 'border-slate-200 focus:border-indigo-600'
                }`}
              />
              {errors.price && <p className="text-rose-600 text-[11px] mt-1">{errors.price}</p>}
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">
                Original / Retail Price ($)
              </label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                value={originalPrice}
                onChange={e => setOriginalPrice(e.target.value)}
                placeholder="199.99 (optional)"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 focus:outline-none focus:bg-white focus:border-indigo-600"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">
                Stock Quantity <span className="text-rose-600">*</span>
              </label>
              <input
                id="product-form-stock"
                type="number"
                min="0"
                value={stock}
                onChange={e => setStock(e.target.value)}
                placeholder="25"
                className={`w-full bg-slate-50 border rounded-xl px-3.5 py-2 text-slate-900 focus:outline-none focus:bg-white ${
                  errors.stock ? 'border-rose-500' : 'border-slate-200 focus:border-indigo-600'
                }`}
              />
              {errors.stock && <p className="text-rose-600 text-[11px] mt-1">{errors.stock}</p>}
            </div>
          </div>

          {/* Row 4: Image URL with quick presets */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1.5">
              Image URL <span className="text-rose-600">*</span>
            </label>
            <div className="flex gap-2">
              <input
                id="product-form-image"
                type="text"
                value={imageUrl}
                onChange={e => setImageUrl(e.target.value)}
                placeholder="https://images.unsplash.com/..."
                className={`flex-1 bg-slate-50 border rounded-xl px-3.5 py-2 text-slate-900 focus:outline-none focus:bg-white ${
                  errors.imageUrl ? 'border-rose-500' : 'border-slate-200 focus:border-indigo-600'
                }`}
              />
            </div>

            {/* Quick Sample Presets */}
            <div className="flex items-center gap-2 mt-2 overflow-x-auto pb-1">
              <span className="text-[11px] text-slate-500 shrink-0">Sample Presets:</span>
              {SAMPLE_IMAGES.map((img, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setImageUrl(img.url)}
                  className="px-2 py-0.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 text-[11px] shrink-0 cursor-pointer"
                >
                  {img.label}
                </button>
              ))}
            </div>

            {/* Image Preview */}
            {imageUrl && (
              <div className="mt-2.5 flex items-center gap-3 p-2 bg-slate-50 rounded-xl border border-slate-200">
                <img
                  src={imageUrl}
                  alt="Preview"
                  referrerPolicy="no-referrer"
                  className="w-14 h-14 rounded-lg object-cover bg-slate-100 border border-slate-200"
                  onError={e => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
                <div>
                  <span className="text-xs font-semibold text-indigo-700 block">Preview Loaded</span>
                  <span className="text-[11px] text-slate-500 line-clamp-1">{imageUrl}</span>
                </div>
              </div>
            )}
          </div>

          {/* Row 5: Description */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1.5">
              Product Description <span className="text-rose-600">*</span>
            </label>
            <textarea
              id="product-form-desc"
              rows={3}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Detailed description of features, materials, and usage..."
              className={`w-full bg-slate-50 border rounded-xl p-3 text-slate-900 focus:outline-none focus:bg-white ${
                errors.description ? 'border-rose-500' : 'border-slate-200 focus:border-indigo-600'
              }`}
            />
            {errors.description && <p className="text-rose-600 text-[11px] mt-1">{errors.description}</p>}
          </div>

          {/* Row 6: Tags */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1.5">
              Tags (comma separated)
            </label>
            <input
              type="text"
              value={tagsInput}
              onChange={e => setTagsInput(e.target.value)}
              placeholder="Athletic, Running, Lightweight"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 focus:outline-none focus:bg-white focus:border-indigo-600"
            />
          </div>

          {/* Row 7: Dynamic Specifications */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="font-semibold text-slate-700">Technical Specifications</label>
              <button
                type="button"
                onClick={handleAddSpec}
                className="text-indigo-600 hover:text-indigo-700 flex items-center gap-1 font-semibold cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Row</span>
              </button>
            </div>

            <div className="space-y-2">
              {specs.map((spec, i) => (
                <div key={i} className="flex items-center gap-2">
                  <input
                    type="text"
                    value={spec.key}
                    onChange={e => handleSpecChange(i, 'key', e.target.value)}
                    placeholder="Spec Name (e.g. Weight)"
                    className="w-1/3 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-slate-900 focus:outline-none focus:bg-white focus:border-indigo-600"
                  />
                  <input
                    type="text"
                    value={spec.value}
                    onChange={e => handleSpecChange(i, 'value', e.target.value)}
                    placeholder="Value (e.g. 210g)"
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-slate-900 focus:outline-none focus:bg-white focus:border-indigo-600"
                  />
                  <button
                    type="button"
                    onClick={() => handleRemoveSpec(i)}
                    className="p-2 text-slate-400 hover:text-rose-600 transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Modal Actions */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              id="submit-product-form-btn"
              type="submit"
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold transition shadow-xs cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>{isEditing ? 'Save Changes' : 'Create Product'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
