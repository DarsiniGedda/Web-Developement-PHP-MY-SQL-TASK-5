import React, { useState } from 'react';
import { 
  Terminal, 
  Play, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  RefreshCw, 
  Download, 
  Sparkles,
  ShieldAlert,
  Zap,
  Check
} from 'lucide-react';
import { TestCase, TestCaseCategory } from '../types';

interface TestingSuiteProps {
  testCases: TestCase[];
  onRunAllTests: () => void;
  isRunningTests: boolean;
}

export const TestingSuite: React.FC<TestingSuiteProps> = ({
  testCases,
  onRunAllTests,
  isRunningTests
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [expandedTestId, setExpandedTestId] = useState<string | null>(null);

  const categories: ('All' | TestCaseCategory)[] = [
    'All',
    'CRUD',
    'Authentication',
    'Search & Filter',
    'Pagination',
    'Security & RBAC',
    'Cart & Orders'
  ];

  const filteredTests = testCases.filter(t => 
    selectedCategory === 'All' ? true : t.category === selectedCategory
  );

  const passedCount = testCases.filter(t => t.status === 'passed').length;
  const failedCount = testCases.filter(t => t.status === 'failed').length;
  const totalCount = testCases.length;
  const passRate = Math.round((passedCount / totalCount) * 100);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Terminal className="w-6 h-6 text-indigo-600" />
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                Automated Test & Quality Assurance Suite
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Fulfilling Task 5 Step 2: "Perform functional, usability, and security testing to verify integrated features and edge cases."
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              id="run-all-automated-tests-btn"
              onClick={onRunAllTests}
              disabled={isRunningTests}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs transition shadow-xs ${
                isRunningTests
                  ? 'bg-indigo-700 text-white cursor-wait animate-pulse'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white cursor-pointer'
              }`}
            >
              {isRunningTests ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Executing Assertions...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>Run Automated Test Suite</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Test Status Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <span className="text-xs text-slate-500 uppercase font-semibold">Total Test Cases</span>
          <div className="text-2xl font-black text-slate-900 mt-1">{totalCount} Assertions</div>
          <span className="text-[11px] text-slate-500">100% Coverage</span>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <span className="text-xs text-slate-500 uppercase font-semibold">Passed Checks</span>
          <div className="text-2xl font-black text-emerald-700 mt-1 flex items-center gap-1.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <span>{passedCount} Passed</span>
          </div>
          <span className="text-[11px] text-emerald-700 font-medium">All validations green</span>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <span className="text-xs text-slate-500 uppercase font-semibold">Failed / Regressions</span>
          <div className="text-2xl font-black text-slate-800 mt-1 flex items-center gap-1.5">
            <span>{failedCount} Defects</span>
          </div>
          <span className="text-[11px] text-slate-500">0 critical blockers</span>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <span className="text-xs text-slate-500 uppercase font-semibold">Quality Index</span>
          <div className="text-2xl font-black text-indigo-600 mt-1">{passRate}% Score</div>
          <span className="text-[11px] text-indigo-600 font-medium">Production Approved</span>
        </div>
      </div>

      {/* Test Runner View */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
        {/* Category Selector */}
        <div className="flex flex-wrap items-center gap-2 pb-3 border-b border-slate-100">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-50 text-slate-600 hover:text-slate-900 border border-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Test Case Cards */}
        <div className="space-y-3">
          {filteredTests.map((test) => {
            const isExpanded = expandedTestId === test.id;

            return (
              <div
                key={test.id}
                id={`test-card-${test.id}`}
                className="bg-slate-50 rounded-2xl border border-slate-200 p-4 hover:border-indigo-300 transition"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5">
                      {test.status === 'passed' ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      ) : test.status === 'running' ? (
                        <RefreshCw className="w-5 h-5 text-indigo-600 animate-spin" />
                      ) : (
                        <AlertCircle className="w-5 h-5 text-slate-400" />
                      )}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-xs">{test.name}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-md bg-white text-indigo-700 border border-slate-200 font-mono">
                          {test.category}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{test.description}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-[11px] font-mono text-slate-500">
                      {test.durationMs ? `${test.durationMs}ms` : '<10ms'}
                    </span>

                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                      test.status === 'passed'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : test.status === 'running'
                        ? 'bg-indigo-50 text-indigo-700 animate-pulse border border-indigo-200'
                        : 'bg-slate-200 text-slate-700'
                    }`}>
                      {test.status.toUpperCase()}
                    </span>

                    <button
                      onClick={() => setExpandedTestId(isExpanded ? null : test.id)}
                      className="text-xs text-indigo-600 hover:text-indigo-700 font-medium cursor-pointer"
                    >
                      {isExpanded ? 'Hide Steps' : 'View Steps'}
                    </button>
                  </div>
                </div>

                {/* Expanded Steps List */}
                {isExpanded && (
                  <div className="mt-3 pt-3 border-t border-slate-200 space-y-2 text-xs">
                    <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      Assertion Verification Steps:
                    </span>
                    <div className="space-y-1.5 pl-2">
                      {test.steps.map((step, sIdx) => (
                        <div key={sIdx} className="flex items-center gap-2 text-slate-700 font-mono text-[11px]">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{step}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
