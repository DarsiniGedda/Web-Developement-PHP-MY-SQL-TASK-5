import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  ShoppingBag, 
  ArrowRight, 
  CheckCircle2, 
  ShieldCheck, 
  Sparkles,
  Tag,
  CreditCard,
  Download
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { CartItem, Order } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onPlaceOrder: (order: Order) => void;
  userName: string;
  userEmail: string;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onPlaceOrder,
  userName,
  userEmail
}) => {
  const [promoCode, setPromoCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState<{ code: string; percent?: number; amount?: number } | null>(null);
  const [promoError, setPromoError] = useState('');
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [orderComplete, setOrderComplete] = useState<Order | null>(null);

  if (!isOpen) return null;

  const subtotal = cartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  
  let discountAmount = 0;
  if (appliedDiscount) {
    if (appliedDiscount.percent) {
      discountAmount = (subtotal * appliedDiscount.percent) / 100;
    } else if (appliedDiscount.amount) {
      discountAmount = Math.min(subtotal, appliedDiscount.amount);
    }
  }

  const shipping = subtotal > 150 || subtotal === 0 ? 0 : 9.99;
  const taxableAmount = Math.max(0, subtotal - discountAmount);
  const tax = taxableAmount * 0.0825; // 8.25%
  const finalTotal = Math.max(0, taxableAmount + tax + shipping);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError('');
    const code = promoCode.trim().toUpperCase();
    if (code === 'APEX20') {
      setAppliedDiscount({ code: 'APEX20', percent: 20 });
    } else if (code === 'TASK5' || code === 'APEXPLANET') {
      setAppliedDiscount({ code, amount: 25 });
    } else {
      setPromoError('Invalid promo code. Try "APEX20" or "TASK5"');
    }
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newOrder: Order = {
      id: 'ORD-' + Math.floor(Math.random() * 900000 + 100000),
      items: [...cartItems],
      subtotal,
      tax,
      discount: discountAmount,
      shipping,
      total: finalTotal,
      customerName: userName,
      customerEmail: userEmail,
      status: 'Processing',
      createdAt: new Date().toISOString(),
      paymentMethod: 'Apex Express Pay (Simulated)'
    };

    onPlaceOrder(newOrder);
    setOrderComplete(newOrder);
    onClearCart();
    setIsCheckingOut(false);

    // Confetti celebration
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // Ignore if canvas-confetti is not loaded
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/50 backdrop-blur-xs animate-in fade-in">
      <div className="w-full max-w-md bg-white border-l border-slate-200 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-300">
        {/* Drawer Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-indigo-600" />
            <h2 className="font-bold text-slate-900 text-base">Your Cart</h2>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 font-semibold border border-indigo-200">
              {cartItems.reduce((sum, item) => sum + item.quantity, 0)} items
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-900 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Order Complete Screen */}
        {orderComplete ? (
          <div className="p-6 overflow-y-auto space-y-5 flex-1 flex flex-col justify-center items-center text-center">
            <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-lg font-bold text-slate-900">Order Confirmed!</h3>
              <p className="text-xs text-slate-500 mt-1">
                Receipt #{orderComplete.id} generated for {orderComplete.customerName}
              </p>
            </div>

            <div className="w-full bg-slate-50 rounded-2xl p-4 border border-slate-200 text-xs space-y-2 text-left">
              <div className="flex justify-between text-slate-500">
                <span>Order Total:</span>
                <span className="text-indigo-600 font-bold">${orderComplete.total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Payment:</span>
                <span className="text-slate-700 font-medium">{orderComplete.paymentMethod}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Estimated Delivery:</span>
                <span className="text-slate-700 font-medium">2-3 Business Days</span>
              </div>
            </div>

            <button
              onClick={() => {
                setOrderComplete(null);
                onClose();
              }}
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition shadow-xs cursor-pointer"
            >
              Continue Shopping
            </button>
          </div>
        ) : isCheckingOut ? (
          /* Checkout View */
          <form onSubmit={handleCheckoutSubmit} className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <span className="font-bold text-slate-900">Checkout Details</span>
              <button
                type="button"
                onClick={() => setIsCheckingOut(false)}
                className="text-xs text-indigo-600 hover:underline cursor-pointer"
              >
                Back to Cart
              </button>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Customer Full Name</label>
              <input
                type="text"
                required
                defaultValue={userName}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:bg-white focus:border-indigo-600"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Email Address</label>
              <input
                type="email"
                required
                defaultValue={userEmail}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:bg-white focus:border-indigo-600"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Shipping Address</label>
              <input
                type="text"
                required
                defaultValue="Apex Tech Campus, Suite 400, Silicon Valley"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:bg-white focus:border-indigo-600"
              />
            </div>

            <div className="pt-2">
              <label className="block text-slate-700 font-semibold mb-1">Payment Method</label>
              <div className="p-3 bg-slate-50 border border-indigo-200 rounded-xl flex items-center gap-3">
                <CreditCard className="w-5 h-5 text-indigo-600" />
                <div className="flex-1">
                  <span className="font-semibold text-slate-900 block">Simulated Express Checkout</span>
                  <span className="text-[10px] text-slate-500">Sandbox Test Card **** 4242</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-bold border border-indigo-200">
                  ACTIVE
                </span>
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5 text-[11px]">
              <div className="flex justify-between text-slate-500">
                <span>Subtotal:</span>
                <span className="text-slate-900 font-semibold">${subtotal.toFixed(2)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700 font-semibold">
                  <span>Discount:</span>
                  <span>-${discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-500">
                <span>Estimated Tax (8.25%):</span>
                <span className="text-slate-900">${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Shipping:</span>
                <span className="text-slate-900">{shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}</span>
              </div>
              <div className="flex justify-between text-xs font-bold text-slate-900 pt-1.5 border-t border-slate-200">
                <span>Total Due:</span>
                <span className="text-indigo-600 font-extrabold">${finalTotal.toFixed(2)}</span>
              </div>
            </div>

            <button
              id="confirm-checkout-order-btn"
              type="submit"
              className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition shadow-xs cursor-pointer"
            >
              Pay ${finalTotal.toFixed(2)} & Complete Order
            </button>
          </form>
        ) : (
          /* Normal Cart List */
          <div className="flex-1 flex flex-col justify-between overflow-hidden">
            {cartItems.length === 0 ? (
              <div className="p-8 text-center my-auto space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
                  <ShoppingBag className="w-7 h-7" />
                </div>
                <h3 className="font-bold text-slate-900 text-sm">Your cart is empty</h3>
                <p className="text-xs text-slate-500">
                  Explore the catalog and add products to start an order.
                </p>
              </div>
            ) : (
              <div className="p-5 overflow-y-auto space-y-3 flex-1">
                {cartItems.map(item => (
                  <div
                    key={item.product.id}
                    className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center gap-3 shadow-xs"
                  >
                    <img
                      src={item.product.imageUrl}
                      alt={item.product.name}
                      referrerPolicy="no-referrer"
                      className="w-14 h-14 rounded-xl object-cover bg-slate-100 border border-slate-200 shrink-0"
                    />

                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-slate-900 text-xs truncate" title={item.product.name}>
                        {item.product.name}
                      </h4>
                      <span className="text-[11px] font-mono text-indigo-600 font-semibold block mt-0.5">
                        ${item.product.price.toFixed(2)} each
                      </span>

                      {/* Quantity Stepper */}
                      <div className="flex items-center gap-2 mt-2">
                        <div className="flex items-center bg-slate-50 border border-slate-200 rounded-lg">
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                            className="px-2 py-0.5 text-slate-600 hover:text-slate-900 text-xs cursor-pointer"
                          >
                            -
                          </button>
                          <span className="px-2 py-0.5 text-xs font-bold text-slate-900">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                            disabled={item.quantity >= item.product.stock}
                            className="px-2 py-0.5 text-slate-600 hover:text-slate-900 disabled:opacity-40 text-xs cursor-pointer"
                          >
                            +
                          </button>
                        </div>

                        <span className="text-xs font-bold text-slate-900 ml-auto">
                          ${(item.product.price * item.quantity).toFixed(2)}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => onRemoveItem(item.product.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 transition cursor-pointer"
                      title="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Cart Footer */}
            {cartItems.length > 0 && (
              <div className="p-5 border-t border-slate-100 bg-slate-50/80 space-y-3">
                {/* Promo Code input */}
                <form onSubmit={handleApplyPromo} className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={promoCode}
                      onChange={e => setPromoCode(e.target.value)}
                      placeholder="Promo (APEX20, TASK5)"
                      className="w-full bg-white border border-slate-200 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-900 placeholder-slate-400 uppercase focus:outline-none focus:border-indigo-600"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 border border-slate-200 cursor-pointer"
                  >
                    Apply
                  </button>
                </form>

                {appliedDiscount && (
                  <div className="flex items-center justify-between text-[11px] text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                    <span>Coupon "{appliedDiscount.code}" applied!</span>
                    <button onClick={() => setAppliedDiscount(null)} className="text-slate-400 hover:text-slate-900 cursor-pointer">✕</button>
                  </div>
                )}

                {promoError && (
                  <p className="text-[11px] text-rose-600">{promoError}</p>
                )}

                {/* Subtotal & Total Summary */}
                <div className="space-y-1 text-xs text-slate-600">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Subtotal:</span>
                    <span className="font-semibold text-slate-900">${subtotal.toFixed(2)}</span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between text-emerald-700 font-semibold">
                      <span>Discount:</span>
                      <span>-${discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-slate-500">Shipping:</span>
                    <span>{shipping === 0 ? <strong className="text-emerald-700">FREE</strong> : `$${shipping.toFixed(2)}`}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-slate-900 pt-2 border-t border-slate-200">
                    <span>Est. Total:</span>
                    <span className="text-indigo-600 font-extrabold">${finalTotal.toFixed(2)}</span>
                  </div>
                </div>

                {/* Checkout Button */}
                <button
                  id="cart-proceed-checkout-btn"
                  onClick={() => setIsCheckingOut(true)}
                  className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-2 transition shadow-xs cursor-pointer"
                >
                  <span>Proceed to Checkout</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
