import React, { useState, useMemo } from 'react';
import { 
  Plus, 
  Search, 
  Trash2, 
  Edit3, 
  Download, 
  Eye, 
  Copy, 
  AlertCircle, 
  CheckSquare, 
  Square, 
  SlidersHorizontal, 
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  ShieldAlert,
  ArrowUpDown,
  DollarSign,
  Package,
  Layers,
  Sparkles
} from 'lucide-react';
import { Product, ProductCategory, User } from '../types';
import { exportToCSV, checkPermission } from '../utils/security';

interface ProductManagementProps {
  products: Product[];
  currentUser: User;
  onOpenCreateModal: () => void;
  onOpenEditModal: (product: Product) => void;
  onDeleteProduct: (product: Product) => void;
  onBulkDelete: (productIds: string[]) => void;
  onBulkCategoryChange: (productIds: string[], category: ProductCategory) => void;
  onDuplicateProduct: (product: Product) => void;
  onQuickView: (product: Product) => void;
}

export const ProductManagement: React.FC<ProductManagementProps> = ({
  products,
  currentUser,
  onOpenCreateModal,
  onOpenEditModal,
  onDeleteProduct,
  onBulkDelete,
  onBulkCategoryChange,
  onDuplicateProduct,
  onQuickView
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedStockStatus, setSelectedStockStatus] = useState<string>('All');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<'name' | 'price' | 'stock' | 'rating' | 'updated'>('updated');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [itemsPerPage, setItemsPerPage] = useState<number>(8);
  const [deleteTarget, setDeleteTarget] = useState<Product | null>(null);
  const [bulkActionType, setBulkActionType] = useState<string>('');

  const canCreate = checkPermission(currentUser.role, 'CREATE');
  const canDelete = checkPermission(currentUser.role, 'DELETE');
  const canUpdate = checkPermission(currentUser.role, 'UPDATE');

  // Filtering
  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = product.name.toLowerCase().includes(q);
        const matchSku = product.sku.toLowerCase().includes(q);
        const matchCategory = product.category.toLowerCase().includes(q);
        const matchTags = product.tags.some(t => t.toLowerCase().includes(q));
        if (!matchName && !matchSku && !matchCategory && !matchTags) return false;
      }

      if (selectedCategory !== 'All' && product.category !== selectedCategory) {
        return false;
      }

      if (selectedStockStatus !== 'All') {
        if (selectedStockStatus === 'In Stock' && product.stock <= 10) return false;
        if (selectedStockStatus === 'Low Stock' && (product.stock === 0 || product.stock > 10)) return false;
        if (selectedStockStatus === 'Out of Stock' && product.stock > 0) return false;
      }

      return true;
    });
  }, [products, searchQuery, selectedCategory, selectedStockStatus]);

  // Sorting
  const sortedProducts = useMemo(() => {
    return [...filteredProducts].sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'name') comparison = a.name.localeCompare(b.name);
      else if (sortBy === 'price') comparison = a.price - b.price;
      else if (sortBy === 'stock') comparison = a.stock - b.stock;
      else if (sortBy === 'rating') comparison = a.rating - b.rating;
      else if (sortBy === 'updated') comparison = new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime();

      return sortOrder === 'asc' ? comparison : -comparison;
    });
  }, [filteredProducts, sortBy, sortOrder]);

  // Pagination
  const totalPages = Math.ceil(sortedProducts.length / itemsPerPage) || 1;
  const clampedPage = Math.min(Math.max(1, currentPage), totalPages);
  const startIndex = (clampedPage - 1) * itemsPerPage;
  const paginatedProducts = sortedProducts.slice(startIndex, startIndex + itemsPerPage);

  const handleSelectAll = () => {
    if (selectedIds.length === paginatedProducts.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(paginatedProducts.map(p => p.id));
    }
  };

  const toggleSelectOne = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleSort = (field: 'name' | 'price' | 'stock' | 'rating' | 'updated') => {
    if (sortBy === field) {
      setSortOrder(prev => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
  };

  const handleExportData = () => {
    const exportRows = products.map(p => ({
      ID: p.id,
      SKU: p.sku,
      Name: p.name,
      Category: p.category,
      Price: p.price,
      Stock: p.stock,
      Rating: p.rating,
      Reviews: p.reviewsCount,
      Tags: p.tags.join('; '),
      Brand: p.brand,
      LastUpdated: p.updatedAt
    }));
    exportToCSV('ApexPlanet_Inventory_Catalog', exportRows);
  };

  const handleExecuteBulkAction = () => {
    if (!selectedIds.length) return;
    if (bulkActionType === 'delete') {
      if (!canDelete) {
        alert('Permission Denied: Only Admin role can perform bulk deletions.');
        return;
      }
      onBulkDelete(selectedIds);
      setSelectedIds([]);
      setBulkActionType('');
    } else if (bulkActionType.startsWith('category:')) {
      const newCat = bulkActionType.replace('category:', '') as ProductCategory;
      onBulkCategoryChange(selectedIds, newCat);
      setSelectedIds([]);
      setBulkActionType('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Enterprise Catalog & CRUD Engine
            </h2>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 font-semibold border border-indigo-200">
              {products.length} Total SKUs
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Perform granular Create, Read, Update, Delete operations with atomic validation, bulk mutations, and automatic audit trail synchronization.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleExportData}
            id="export-inventory-csv-btn"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 transition shadow-xs cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-indigo-600" />
            <span>Export CSV</span>
          </button>

          <button
            id="open-create-product-btn"
            onClick={onOpenCreateModal}
            disabled={!canCreate}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition shadow-xs ${
              canCreate
                ? 'bg-indigo-600 hover:bg-indigo-700 text-white cursor-pointer'
                : 'bg-slate-100 text-slate-400 cursor-not-allowed opacity-60'
            }`}
            title={canCreate ? 'Create New Product' : 'Creation Locked (Requires Admin or Manager role)'}
          >
            <Plus className="w-4 h-4" />
            <span>{canCreate ? 'Add New Product' : 'Creation Locked (Admin/Manager)'}</span>
          </button>
        </div>
      </div>

      {/* Filter and Bulk Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="crud-search-input"
              type="text"
              value={searchQuery}
              onChange={e => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Filter by SKU, Name, Category, or Tags..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9.5 pr-4 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 transition"
            />
          </div>

          {/* Category Dropdown */}
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={selectedCategory}
              onChange={e => {
                setSelectedCategory(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-slate-50 border border-slate-200 text-xs text-slate-700 rounded-xl px-3 py-2 focus:outline-none focus:bg-white focus:border-indigo-600 cursor-pointer"
            >
              <option value="All">All Categories</option>
              <option value="Footwear">Footwear</option>
              <option value="Apparel">Apparel</option>
              <option value="Accessories">Accessories</option>
              <option value="Electronics">Electronics</option>
              <option value="Office & Tech">Office & Tech</option>
            </select>

            <select
              value={selectedStockStatus}
              onChange={e => {
                setSelectedStockStatus(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-slate-50 border border-slate-200 text-xs text-slate-700 rounded-xl px-3 py-2 focus:outline-none focus:bg-white focus:border-indigo-600 cursor-pointer"
            >
              <option value="All">All Stock Levels</option>
              <option value="In Stock">In Stock (&gt;10)</option>
              <option value="Low Stock">Low Stock (1-10)</option>
              <option value="Out of Stock">Out of Stock (0)</option>
            </select>

            {(searchQuery || selectedCategory !== 'All' || selectedStockStatus !== 'All') && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                  setSelectedStockStatus('All');
                  setCurrentPage(1);
                }}
                className="p-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-500 hover:text-slate-900 cursor-pointer"
                title="Reset filters"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Bulk Action Controls */}
        {selectedIds.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 p-2.5 rounded-xl bg-indigo-50 border border-indigo-200 animate-in fade-in">
            <div className="flex items-center gap-2 text-xs text-indigo-900 font-semibold">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>{selectedIds.length} items selected</span>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={bulkActionType}
                onChange={e => setBulkActionType(e.target.value)}
                className="bg-white border border-slate-200 text-xs text-slate-900 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-indigo-600 cursor-pointer"
              >
                <option value="">Choose Bulk Action...</option>
                {canDelete && <option value="delete">Bulk Delete</option>}
                <option value="category:Footwear">Move to Footwear</option>
                <option value="category:Apparel">Move to Apparel</option>
                <option value="category:Accessories">Move to Accessories</option>
                <option value="category:Electronics">Move to Electronics</option>
                <option value="category:Office & Tech">Move to Office & Tech</option>
              </select>

              <button
                onClick={handleExecuteBulkAction}
                disabled={!bulkActionType}
                className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold transition cursor-pointer"
              >
                Apply
              </button>

              <button
                onClick={() => setSelectedIds([])}
                className="text-xs text-slate-500 hover:text-slate-900 px-2 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Main Data Table */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                <th className="p-3.5 w-10 text-center">
                  <button
                    onClick={handleSelectAll}
                    className="text-slate-400 hover:text-slate-900 cursor-pointer"
                  >
                    {selectedIds.length > 0 && selectedIds.length === paginatedProducts.length ? (
                      <CheckSquare className="w-4 h-4 text-indigo-600" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-400" />
                    )}
                  </button>
                </th>
                <th 
                  onClick={() => handleSort('name')}
                  className="p-3.5 cursor-pointer hover:text-indigo-600 transition select-none"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Product & SKU</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="p-3.5">Category</th>
                <th 
                  onClick={() => handleSort('price')}
                  className="p-3.5 cursor-pointer hover:text-indigo-600 transition select-none"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Price</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th 
                  onClick={() => handleSort('stock')}
                  className="p-3.5 cursor-pointer hover:text-indigo-600 transition select-none"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Stock</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th 
                  onClick={() => handleSort('rating')}
                  className="p-3.5 cursor-pointer hover:text-indigo-600 transition select-none"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Rating</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th 
                  onClick={() => handleSort('updated')}
                  className="p-3.5 cursor-pointer hover:text-indigo-600 transition select-none"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Updated</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {paginatedProducts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    <p className="font-semibold text-sm text-slate-700">No matching products in database</p>
                    <p className="text-xs text-slate-400 mt-1">Adjust your filters or add a new SKU</p>
                  </td>
                </tr>
              ) : (
                paginatedProducts.map(product => {
                  const isSelected = selectedIds.includes(product.id);
                  const isLowStock = product.stock > 0 && product.stock <= 10;
                  const isOutOfStock = product.stock === 0;

                  return (
                    <tr
                      key={product.id}
                      id={`crud-row-${product.id}`}
                      className={`hover:bg-slate-50 transition ${
                        isSelected ? 'bg-indigo-50/50' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="p-3.5 text-center">
                        <button
                          onClick={() => toggleSelectOne(product.id)}
                          className="text-slate-400 hover:text-slate-900 cursor-pointer"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-indigo-600" />
                          ) : (
                            <Square className="w-4 h-4 text-slate-400" />
                          )}
                        </button>
                      </td>

                      {/* Product details */}
                      <td className="p-3.5">
                        <div className="flex items-center space-x-3">
                          <img
                            src={product.imageUrl}
                            alt={product.name}
                            referrerPolicy="no-referrer"
                            className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0 border border-slate-200"
                          />
                          <div>
                            <span className="font-bold text-slate-900 block max-w-xs truncate" title={product.name}>
                              {product.name}
                            </span>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="font-mono text-[11px] text-indigo-600 font-semibold">{product.sku}</span>
                              <span className="text-slate-300">&bull;</span>
                              <span className="text-[11px] text-slate-500">{product.brand}</span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Category */}
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200 text-[11px] font-medium">
                          {product.category}
                        </span>
                      </td>

                      {/* Price */}
                      <td className="p-3.5">
                        <div className="font-bold text-slate-900 text-xs">
                          ${product.price.toFixed(2)}
                        </div>
                        {product.originalPrice && (
                          <div className="text-[10px] text-slate-400 line-through">
                            ${product.originalPrice.toFixed(2)}
                          </div>
                        )}
                      </td>

                      {/* Stock */}
                      <td className="p-3.5">
                        <div className="flex items-center gap-1.5">
                          <span className={`w-2 h-2 rounded-full ${
                            isOutOfStock ? 'bg-rose-500' : isLowStock ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'
                          }`} />
                          <span className={`font-semibold ${
                            isOutOfStock ? 'text-rose-600' : isLowStock ? 'text-amber-600' : 'text-slate-700'
                          }`}>
                            {product.stock} units
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400 block mt-0.5">
                          {isOutOfStock ? 'Out of stock' : isLowStock ? 'Restock Soon' : 'Optimal'}
                        </span>
                      </td>

                      {/* Rating */}
                      <td className="p-3.5">
                        <div className="flex items-center gap-1 text-amber-500 font-bold">
                          <span>★ {product.rating}</span>
                          <span className="text-slate-400 font-normal text-[10px]">({product.reviewsCount})</span>
                        </div>
                      </td>

                      {/* Updated */}
                      <td className="p-3.5 text-slate-500 text-[11px]">
                        {new Date(product.updatedAt).toLocaleDateString()}
                      </td>

                      {/* Actions */}
                      <td className="p-3.5 text-right">
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            onClick={() => onQuickView(product)}
                            className="p-1.5 rounded-lg bg-slate-100 text-slate-600 hover:text-slate-900 hover:bg-slate-200 transition cursor-pointer"
                            title="Quick View"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => onDuplicateProduct(product)}
                            disabled={!canCreate}
                            className={`p-1.5 rounded-lg transition ${
                              canCreate
                                ? 'bg-slate-100 text-slate-600 hover:text-indigo-600 hover:bg-slate-200 cursor-pointer'
                                : 'bg-slate-50 text-slate-300 cursor-not-allowed'
                            }`}
                            title={canCreate ? 'Duplicate Product' : 'Restricted'}
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>

                          <button
                            id={`edit-product-${product.id}`}
                            onClick={() => onOpenEditModal(product)}
                            disabled={!canUpdate}
                            className={`p-1.5 rounded-lg transition ${
                              canUpdate
                                ? 'bg-slate-100 text-slate-600 hover:text-amber-600 hover:bg-slate-200 cursor-pointer'
                                : 'bg-slate-50 text-slate-300 cursor-not-allowed'
                            }`}
                            title={canUpdate ? 'Edit Product' : 'Restricted to Admin/Manager'}
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            id={`delete-product-${product.id}`}
                            onClick={() => {
                              if (!canDelete) {
                                alert('Security Lock: Only Admin role has permission to delete products.');
                                return;
                              }
                              setDeleteTarget(product);
                            }}
                            disabled={!canDelete}
                            className={`p-1.5 rounded-lg transition ${
                              canDelete
                                ? 'bg-slate-100 text-rose-600 hover:text-white hover:bg-rose-600 cursor-pointer'
                                : 'bg-slate-50 text-slate-300 cursor-not-allowed'
                            }`}
                            title={canDelete ? 'Delete Product' : 'Restricted to Admin'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="text-slate-500">
            Showing <strong className="text-slate-900">{startIndex + 1}</strong> to <strong className="text-slate-900">{Math.min(startIndex + itemsPerPage, sortedProducts.length)}</strong> of <strong className="text-slate-900">{sortedProducts.length}</strong> records
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={clampedPage === 1}
              className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-slate-100 transition cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <span className="font-semibold text-slate-700 px-2">
              Page {clampedPage} of {totalPages}
            </span>

            <button
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={clampedPage === totalPages}
              className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-slate-100 transition cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Confirm Product Deletion</h3>
                <p className="text-xs text-slate-500">This action will be recorded in the security audit log</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Are you sure you want to permanently delete <strong className="text-slate-900">"{deleteTarget.name}"</strong> (<span className="font-mono text-indigo-600 font-semibold">{deleteTarget.sku}</span>)?
            </p>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                id="confirm-delete-action-btn"
                onClick={() => {
                  onDeleteProduct(deleteTarget);
                  setDeleteTarget(null);
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition shadow-xs cursor-pointer"
              >
                Delete Product
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
