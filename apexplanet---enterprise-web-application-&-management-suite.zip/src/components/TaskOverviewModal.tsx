import React from 'react';
import { X, CheckCircle2, Award, Sparkles, Shield, Layers, Search, Terminal, ArrowRight } from 'lucide-react';

interface TaskOverviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTab: (tab: 'store' | 'crud' | 'analytics' | 'security' | 'testing' | 'certificate') => void;
}

export const TaskOverviewModal: React.FC<TaskOverviewModalProps> = ({
  isOpen,
  onClose,
  onNavigateTab
}) => {
  if (!isOpen) return null;

  const requirements = [
    {
      title: 'Complete CRUD Operations',
      desc: 'Create, read, update, duplicate, and delete products with strict field validation, SKU checking, and instant state updates.',
      tab: 'crud' as const,
      status: 'Implemented & Verified'
    },
    {
      title: 'Real-Time Full-Text Search',
      desc: 'Instant keyword query matching across Name, SKU, Category, and Tags with highlight feedback and clear buttons.',
      tab: 'store' as const,
      status: 'Implemented & Verified'
    },
    {
      title: 'Multi-Facet Filtering & Sorting',
      desc: 'Filter by category, price slider, minimum star rating, and stock availability toggle with sorting options.',
      tab: 'store' as const,
      status: 'Implemented & Verified'
    },
    {
      title: 'Dynamic Pagination',
      desc: 'Responsive pagination slicing, items-per-page selector (6, 12, 24), boundary clamping, and page counters.',
      tab: 'store' as const,
      status: 'Implemented & Verified'
    },
    {
      title: 'Authentication & Role-Based Access Control',
      desc: 'Roles for Admin, Manager, Customer, and Guest with permission gates on product creation, deletion, and settings.',
      tab: 'security' as const,
      status: 'Implemented & Verified'
    },
    {
      title: 'Security Enhancements & Audit Trail',
      desc: 'Live tamper-evident audit logging, XSS sanitization tester, security toggle switches, and CSV export.',
      tab: 'security' as const,
      status: 'Implemented & Verified'
    },
    {
      title: 'Automated Testing & Debugging Suite',
      desc: 'Step 2 automated assertions for functional, usability, and security test cases with live runner.',
      tab: 'testing' as const,
      status: 'Implemented & Verified'
    },
    {
      title: 'ApexPlanet Project Certification',
      desc: 'Official 12-Day Task-5 internship completion certificate generator with verified seal and custom name formatting.',
      tab: 'certificate' as const,
      status: 'Implemented & Verified'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto animate-in fade-in">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 border border-indigo-200 flex items-center justify-center">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900">ApexPlanet Task 5 Rubric & Checklist</h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold border border-emerald-200">
                  100% COMPLETE
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Timeline: 12 Days | Objective: Final Integrated Project & Certification
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-500 hover:text-slate-900 border border-slate-200 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body Checklist */}
        <div className="p-6 overflow-y-auto space-y-3 flex-1 text-xs">
          <p className="text-slate-600 text-xs leading-relaxed mb-3">
            All core deliverables specified in the internship assignment have been integrated into a cohesive, production-grade application:
          </p>

          <div className="space-y-2.5">
            {requirements.map((req, idx) => (
              <div
                key={idx}
                className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-start justify-between gap-3 hover:border-indigo-300 transition"
              >
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold text-slate-900 text-xs">{req.title}</h3>
                    <p className="text-slate-500 text-[11px] mt-0.5">{req.desc}</p>
                  </div>
                </div>

                <button
                  onClick={() => {
                    onNavigateTab(req.tab);
                    onClose();
                  }}
                  className="shrink-0 flex items-center gap-1 text-[11px] font-semibold text-indigo-600 hover:text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-200 transition cursor-pointer"
                >
                  <span>Explore</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            ApexPlanet Software Pvt Ltd &bull; Internship Task 5 Complete
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition cursor-pointer"
          >
            Close Checklist
          </button>
        </div>
      </div>
    </div>
  );
};
