import { AuditAction, AuditLog, UserRole } from '../types';

/**
 * Sanitizes input text to prevent XSS payloads and script injection
 */
export function sanitizeInput(input: string): string {
  if (!input) return '';
  return input
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/[<>]/g, (tag) => {
      const map: Record<string, string> = { '<': '&lt;', '>': '&gt;' };
      return map[tag] || tag;
    })
    .trim();
}

/**
 * Validates SKU format (e.g. APX-XXX-000)
 */
export function isValidSKU(sku: string): boolean {
  return /^[A-Z0-9]{3,4}-[A-Z0-9]{2,4}-[A-Z0-9]{2,6}$/i.test(sku.trim());
}

/**
 * Generates an audit log entry
 */
export function createAuditLogEntry(
  action: AuditAction,
  actor: string,
  actorRole: UserRole,
  target: string,
  details: string,
  status: 'SUCCESS' | 'WARNING' | 'DENIED' = 'SUCCESS'
): AuditLog {
  const now = new Date();
  const timestamp = now.toISOString().replace('T', ' ').substring(0, 19);
  
  return {
    id: 'log-' + Math.random().toString(36).substring(2, 9),
    timestamp,
    action,
    actor,
    actorRole,
    target,
    details,
    status,
    ipAddress: '192.168.1.' + Math.floor(Math.random() * 200 + 10)
  };
}

/**
 * Checks role permission for specific action
 */
export function checkPermission(role: UserRole, action: 'CREATE' | 'UPDATE' | 'DELETE' | 'VIEW_ADMIN' | 'MANAGE_SECURITY' | 'RUN_TESTS'): boolean {
  switch (action) {
    case 'CREATE':
    case 'UPDATE':
      return role === 'admin' || role === 'manager';
    case 'DELETE':
    case 'MANAGE_SECURITY':
      return role === 'admin';
    case 'VIEW_ADMIN':
    case 'RUN_TESTS':
      return role === 'admin' || role === 'manager';
    default:
      return false;
  }
}

/**
 * Exports data to downloadable JSON or CSV
 */
export function exportToCSV(filename: string, rows: Record<string, any>[]) {
  if (!rows || !rows.length) return;
  const separator = ',';
  const keys = Object.keys(rows[0]);
  const csvContent =
    keys.join(separator) +
    '\n' +
    rows
      .map(row => {
        return keys
          .map(k => {
            let cell = row[k] === null || row[k] === undefined ? '' : row[k];
            if (typeof cell === 'object') {
              cell = JSON.stringify(cell).replace(/"/g, '""');
            } else {
              cell = cell.toString().replace(/"/g, '""');
            }
            if (cell.search(/("|,|\n)/g) >= 0) {
              cell = `"${cell}"`;
            }
            return cell;
          })
          .join(separator);
      })
      .join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
