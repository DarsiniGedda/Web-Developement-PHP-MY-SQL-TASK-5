import { Product, User, AuditLog, SecuritySettings, TestCase, InternshipCertificateData } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-001',
    name: 'Apex Pro Runner Max V4',
    sku: 'APX-FTW-001',
    category: 'Footwear',
    price: 189.99,
    originalPrice: 229.99,
    stock: 45,
    status: 'In Stock',
    rating: 4.9,
    reviewsCount: 128,
    description: 'High-performance responsive cushioning engineered for elite marathon training and urban sprinting. Features ultra-breathable matrix knit upper with carbon composite torsion plate.',
    tags: ['Athletic', 'Running', 'Carbon-Plate', 'Lightweight'],
    brand: 'Apex Athletics',
    imageUrl: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80',
    badge: 'Sale',
    specs: {
      'Weight': '210g (Size 9)',
      'Sole Material': 'Vibram Traction Rubber',
      'Upper': 'HyperWarp Engineered Mesh',
      'Drop': '8mm'
    },
    createdAt: '2026-08-10T10:00:00Z',
    updatedAt: '2026-08-28T14:30:00Z'
  },
  {
    id: 'prod-002',
    name: 'Velocity Tech Urban Windbreaker',
    sku: 'APX-APP-002',
    category: 'Apparel',
    price: 145.00,
    originalPrice: 165.00,
    stock: 28,
    status: 'In Stock',
    rating: 4.8,
    reviewsCount: 94,
    description: 'Weatherproof ripstop technical shell with laser-cut ventilation and reflective accents. Designed to withstand sudden downpours while providing all-day thermal comfort.',
    tags: ['Waterproof', 'Outerwear', 'Commuter', 'Minimalist'],
    brand: 'Apex Gear',
    imageUrl: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&auto=format&fit=crop&q=80',
    badge: 'Hot',
    specs: {
      'Waterproof Rating': '20,000mm DWR',
      'Pockets': '4 Zippered Seal pockets',
      'Fit': 'Athletic Slim Fit',
      'Material': '100% Recycled Nylon'
    },
    createdAt: '2026-08-12T11:20:00Z',
    updatedAt: '2026-08-25T09:15:00Z'
  },
  {
    id: 'prod-003',
    name: 'Nomad Modular Cyber Backpack 30L',
    sku: 'APX-ACC-003',
    category: 'Accessories',
    price: 169.50,
    stock: 14,
    status: 'In Stock',
    rating: 4.9,
    reviewsCount: 210,
    description: 'Ergonomic water-resistant daily carry with dedicated padded compartments for 16-inch laptops, magnetic Fidlock buckles, and external tripod/jacket carry straps.',
    tags: ['Everyday Carry', 'Tech Pouch', 'Travel', 'Water-Resistant'],
    brand: 'Apex Nomads',
    imageUrl: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&auto=format&fit=crop&q=80',
    badge: 'Featured',
    specs: {
      'Capacity': '30 Liters',
      'Laptop Sleeve': 'Fits up to 16.2" MacBook Pro',
      'Hardware': 'Fidlock V-Buckles & YKK Aquaguard',
      'Fabric': 'Cordura 500D Ballistic'
    },
    createdAt: '2026-08-14T14:40:00Z',
    updatedAt: '2026-08-30T16:00:00Z'
  },
  {
    id: 'prod-004',
    name: 'Apex Sonic Studio Wireless Headphones',
    sku: 'APX-ELC-004',
    category: 'Electronics',
    price: 299.00,
    originalPrice: 349.00,
    stock: 8,
    status: 'Low Stock',
    rating: 4.9,
    reviewsCount: 312,
    description: 'Active Noise Canceling planar magnetic audiophile grade studio headphones with LDAC lossless streaming and 40-hour rapid charge battery life.',
    tags: ['ANC', 'Wireless', 'Audiophile', 'Bluetooth 5.3'],
    brand: 'Apex Audio',
    imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80',
    badge: 'Hot',
    specs: {
      'Driver Size': '50mm Planar Magnetic',
      'Frequency Response': '5Hz - 45,000Hz',
      'Battery Life': '40 Hours with ANC On',
      'Codec Support': 'LDAC, aptX Adaptive, AAC'
    },
    createdAt: '2026-08-05T08:15:00Z',
    updatedAt: '2026-09-01T12:00:00Z'
  },
  {
    id: 'prod-005',
    name: 'Precision Mechanical Workspace Keyboard',
    sku: 'APX-OFF-005',
    category: 'Office & Tech',
    price: 159.00,
    stock: 22,
    status: 'In Stock',
    rating: 4.7,
    reviewsCount: 88,
    description: 'Hot-swappable gasket-mounted 75% mechanical keyboard housed in CNC anodized aerospace aluminum with custom pre-lubricated silent linear switches.',
    tags: ['Mechanical', 'Gasket Mount', 'Wireless 2.4G', 'Aluminum'],
    brand: 'Apex Tech',
    imageUrl: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&auto=format&fit=crop&q=80',
    specs: {
      'Layout': '75% (84 Keys)',
      'Mounting': 'Poron Gasket Mount',
      'Switches': 'Apex Silent Linear 45g',
      'Connectivity': 'Tri-mode (Type-C, 2.4G, BT 5.1)'
    },
    createdAt: '2026-08-18T13:00:00Z',
    updatedAt: '2026-08-29T10:45:00Z'
  },
  {
    id: 'prod-006',
    name: 'Stealth Knit Training Track Pants',
    sku: 'APX-APP-006',
    category: 'Apparel',
    price: 88.00,
    originalPrice: 110.00,
    stock: 35,
    status: 'In Stock',
    rating: 4.6,
    reviewsCount: 75,
    description: 'Four-way stretch engineered jogger tailored for maximum mobility with discreet bonded phone pockets and tapered aerodynamic cuffs.',
    tags: ['Athletic', 'Trousers', 'Gym', 'Breathable'],
    brand: 'Apex Athletics',
    imageUrl: 'https://images.unsplash.com/photo-1506630448388-4e683c67ddb0?w=800&auto=format&fit=crop&q=80',
    badge: 'Sale',
    specs: {
      'Fabric': '86% Nylon, 14% Spandex',
      'Inseam': '29 inches',
      'Care': 'Machine Wash Cold',
      'Features': 'Hidden YKK Zip Phone Holster'
    },
    createdAt: '2026-08-20T16:10:00Z',
    updatedAt: '2026-08-31T08:00:00Z'
  },
  {
    id: 'prod-007',
    name: 'Aero Minimalist Titanium Chrono Watch',
    sku: 'APX-ACC-007',
    category: 'Accessories',
    price: 245.00,
    stock: 4,
    status: 'Low Stock',
    rating: 4.9,
    reviewsCount: 142,
    description: 'Grade 5 Titanium casing with anti-reflective sapphire crystal glass and Japanese automatic sweeping second movement. 100m water resistant.',
    tags: ['Luxury', 'Titanium', 'Sapphire', 'Automatic'],
    brand: 'Apex Horology',
    imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80',
    badge: 'Featured',
    specs: {
      'Case Diameter': '40mm',
      'Case Thickness': '10.2mm',
      'Water Resistance': '10 ATM (100m)',
      'Strap': 'Fluoroelastomer Quick-Release'
    },
    createdAt: '2026-08-01T09:00:00Z',
    updatedAt: '2026-08-27T17:30:00Z'
  },
  {
    id: 'prod-008',
    name: 'Quantum Ergonomic Mesh Executive Chair',
    sku: 'APX-OFF-008',
    category: 'Office & Tech',
    price: 489.00,
    stock: 0,
    status: 'Out of Stock',
    rating: 4.8,
    reviewsCount: 64,
    description: 'Dynamic lumbar spine synchronization system with breathable multi-tier Korean polymer mesh and 4D omnidirectional armrests.',
    tags: ['Ergonomics', 'Desk Setup', 'Office', 'Heavy-Duty'],
    brand: 'Apex Tech',
    imageUrl: 'https://images.unsplash.com/photo-1580481077195-731da89f3799?w=800&auto=format&fit=crop&q=80',
    specs: {
      'Weight Capacity': '350 lbs (158 kg)',
      'Adjustability': '4D Armrests, 135-degree recline',
      'Base': 'Cast Aluminum Polished 5-Star Base',
      'Warranty': '10-Year Comprehensive'
    },
    createdAt: '2026-07-28T12:00:00Z',
    updatedAt: '2026-08-30T11:15:00Z'
  },
  {
    id: 'prod-009',
    name: 'Apex Horizon Trail Hiking Boot',
    sku: 'APX-FTW-009',
    category: 'Footwear',
    price: 215.00,
    stock: 19,
    status: 'In Stock',
    rating: 4.7,
    reviewsCount: 52,
    description: 'Rugged waterproof nubuck leather trail hiking boot equipped with high-grip megagrip lugs and integrated ankle stabilization cradle.',
    tags: ['Hiking', 'Trail', 'Waterproof', 'Outdoor'],
    brand: 'Apex Outdoors',
    imageUrl: 'https://images.unsplash.com/photo-1520639888713-7851133b1ed0?w=800&auto=format&fit=crop&q=80',
    specs: {
      'Membrane': 'Gore-Tex Extended Comfort',
      'Midsole': 'Dual-density compressed EVA',
      'Outsole': 'Vibram Megagrip 5mm lugs',
      'Weight': '440g per shoe'
    },
    createdAt: '2026-08-15T09:30:00Z',
    updatedAt: '2026-08-29T14:00:00Z'
  },
  {
    id: 'prod-010',
    name: '4K Ultra-Wide Curved Studio Monitor 34"',
    sku: 'APX-ELC-010',
    category: 'Electronics',
    price: 649.00,
    originalPrice: 799.00,
    stock: 6,
    status: 'Low Stock',
    rating: 4.9,
    reviewsCount: 188,
    description: '34-inch 1800R curved Nano-IPS panel with 98% DCI-P3 color gamut, 165Hz refresh rate, and Thunderbolt 4 single cable 90W PD connectivity.',
    tags: ['Display', '4K', 'IPS', 'Thunderbolt'],
    brand: 'Apex Displays',
    imageUrl: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=800&auto=format&fit=crop&q=80',
    badge: 'Sale',
    specs: {
      'Resolution': '3440 x 1440 WQHD',
      'Refresh Rate': '165Hz (1ms GtG)',
      'Ports': 'Thunderbolt 4, 2x HDMI 2.1, DP 1.4',
      'Power Delivery': '90W USB-C'
    },
    createdAt: '2026-08-02T10:15:00Z',
    updatedAt: '2026-09-01T15:20:00Z'
  },
  {
    id: 'prod-011',
    name: 'Apex Carbon Smart Flask 750ml',
    sku: 'APX-ACC-011',
    category: 'Accessories',
    price: 54.00,
    stock: 50,
    status: 'In Stock',
    rating: 4.5,
    reviewsCount: 89,
    description: 'Double-wall vacuum insulated smart water bottle with OLED touch display temperature readout and UV-C self-cleaning sterilization cap.',
    tags: ['Hydration', 'Smart', 'Fitness', 'Eco-friendly'],
    brand: 'Apex Tech',
    imageUrl: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=800&auto=format&fit=crop&q=80',
    badge: 'New',
    specs: {
      'Capacity': '750 ml (25.3 oz)',
      'Insulation': '24 hrs Cold / 12 hrs Hot',
      'Sterilization': '99.9% UV-C Purification',
      'Material': '18/8 Pro-Grade Stainless Steel'
    },
    createdAt: '2026-08-22T08:00:00Z',
    updatedAt: '2026-08-30T10:00:00Z'
  },
  {
    id: 'prod-012',
    name: 'Merino Wool Climate Control Hoodie',
    sku: 'APX-APP-012',
    category: 'Apparel',
    price: 135.00,
    stock: 17,
    status: 'In Stock',
    rating: 4.8,
    reviewsCount: 67,
    description: 'Ultra-fine 18.5 micron New Zealand merino wool hoodie offering natural temperature regulation, odor resistance, and unmatched softness.',
    tags: ['Merino Wool', 'Luxury', 'Breathable', 'Sustainable'],
    brand: 'Apex Apparel',
    imageUrl: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800&auto=format&fit=crop&q=80',
    specs: {
      'Fabric Composition': '100% Ultra-Fine Merino Wool',
      'Weight': '260 gsm Midweight',
      'Thumb Loops': 'Integrated Low-Profile Loops',
      'Fit': 'Regular Tailored Cut'
    },
    createdAt: '2026-08-16T15:00:00Z',
    updatedAt: '2026-08-28T12:00:00Z'
  }
];

export const INITIAL_USERS: User[] = [
  {
    id: 'usr-admin',
    name: 'Alex Vance',
    email: 'admin@apexplanet.com',
    role: 'admin',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    department: 'DevOps & Enterprise Security',
    lastLogin: 'Just now',
    token: 'jwt_apex_adm_9948271847192',
    status: 'active'
  },
  {
    id: 'usr-mgr',
    name: 'Sarah Connor',
    email: 'sarah.mgr@apexplanet.com',
    role: 'manager',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
    department: 'Operations & Inventory',
    lastLogin: '24 mins ago',
    token: 'jwt_apex_mgr_8382719283711',
    status: 'active'
  },
  {
    id: 'usr-cust',
    name: 'Darsini Gedda',
    email: 'darsini@apexplanet.com',
    role: 'customer',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80',
    department: 'Full Stack Engineering Intern',
    lastLogin: '1 hour ago',
    token: 'jwt_apex_cst_7281928471928',
    status: 'active'
  },
  {
    id: 'usr-guest',
    name: 'Guest Explorer',
    email: 'guest@apexplanet.com',
    role: 'guest',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80',
    department: 'Public Visitor',
    lastLogin: 'Active session',
    status: 'active'
  }
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log-101',
    timestamp: '2026-09-02 08:24:12',
    action: 'USER_LOGIN',
    actor: 'Alex Vance',
    actorRole: 'admin',
    target: 'Auth Gateway',
    details: 'Authenticated via 2FA OAuth token credentials with TLS 1.3 encryption',
    status: 'SUCCESS',
    ipAddress: '192.168.1.104'
  },
  {
    id: 'log-102',
    timestamp: '2026-09-02 08:18:45',
    action: 'UPDATE_PRODUCT',
    actor: 'Sarah Connor',
    actorRole: 'manager',
    target: 'APX-FTW-001',
    details: 'Price adjusted from $229.99 to $189.99 with tag "Sale"',
    status: 'SUCCESS',
    ipAddress: '192.168.1.112'
  },
  {
    id: 'log-103',
    timestamp: '2026-09-02 08:12:00',
    action: 'SECURITY_CONFIG',
    actor: 'Alex Vance',
    actorRole: 'admin',
    target: 'WAF & Rate Limiter',
    details: 'Activated strict XSS sanitization and payload inspection rules',
    status: 'SUCCESS',
    ipAddress: '192.168.1.104'
  },
  {
    id: 'log-104',
    timestamp: '2026-09-02 07:55:20',
    action: 'CREATE_PRODUCT',
    actor: 'Sarah Connor',
    actorRole: 'manager',
    target: 'APX-ACC-011',
    details: 'Created new product SKU "APX-ACC-011" (Apex Carbon Smart Flask)',
    status: 'SUCCESS',
    ipAddress: '192.168.1.112'
  },
  {
    id: 'log-105',
    timestamp: '2026-09-02 07:30:15',
    action: 'DELETE_PRODUCT',
    actor: 'Darsini Gedda',
    actorRole: 'customer',
    target: 'APX-ELC-004',
    details: 'Unauthorized delete attempt blocked by RBAC security guard policy',
    status: 'DENIED',
    ipAddress: '203.192.88.14'
  }
];

export const INITIAL_SECURITY_SETTINGS: SecuritySettings = {
  rateLimitingEnabled: true,
  xssSanitizationStrict: true,
  sessionTimeoutMinutes: 30,
  requireTwoFactor: true,
  sqlInjectionShield: true,
  auditLoggingEnabled: true
};

export const INITIAL_TEST_CASES: TestCase[] = [
  {
    id: 'test-crud-1',
    name: 'Product Creation (CRUD - C)',
    category: 'CRUD',
    description: 'Verify product creation with payload validation, SKU uniqueness check, and instant state reactivity',
    status: 'passed',
    durationMs: 42,
    steps: [
      'Validate required fields (name, SKU, price > 0, stock >= 0)',
      'Sanitize string inputs against malicious script tags',
      'Assign timestamp & unique identifier',
      'Write to state and log audit trail entry'
    ]
  },
  {
    id: 'test-crud-2',
    name: 'Product Read & Pagination (CRUD - R)',
    category: 'Pagination',
    description: 'Verify pagination slicing, jump to page bounds, and items-per-page recalculations',
    status: 'passed',
    durationMs: 28,
    steps: [
      'Calculate totalPages = Math.ceil(totalFiltered / itemsPerPage)',
      'Enforce clamp bounds (page >= 1 && page <= totalPages)',
      'Slice array accurately [startIndex, endIndex]',
      'Verify reactive rendering across 6, 12, 24 page sizes'
    ]
  },
  {
    id: 'test-crud-3',
    name: 'Product Update & Batch Edits (CRUD - U)',
    category: 'CRUD',
    description: 'Verify individual item edits and multi-item batch status/price modifications',
    status: 'passed',
    durationMs: 65,
    steps: [
      'Locate target record by unique ID',
      'Validate price update numeric integrity',
      'Update stock status badge dynamically based on threshold',
      'Timestamp updatedAt ISO-8601 attribute'
    ]
  },
  {
    id: 'test-crud-4',
    name: 'Product Deletion & Bulk Purge (CRUD - D)',
    category: 'CRUD',
    description: 'Verify safe single deletion with confirmation modal and multi-select bulk delete',
    status: 'passed',
    durationMs: 38,
    steps: [
      'Confirm RBAC role permission (Admin/Manager only)',
      'Prompt confirmation modal with selected item count',
      'Filter out targeted product IDs from collection',
      'Emit notification toast and security audit event'
    ]
  },
  {
    id: 'test-search-1',
    name: 'Live Search & Multi-Facet Filtering',
    category: 'Search & Filter',
    description: 'Verify real-time debounced query filtering across Title, Category, SKU, and Tags',
    status: 'passed',
    durationMs: 31,
    steps: [
      'Apply case-insensitive query substring matching',
      'Intersect with Category filter dropdown',
      'Filter within Price range [minPrice, maxPrice]',
      'Apply Rating filter (>= minRating) and In-Stock toggle'
    ]
  },
  {
    id: 'test-auth-1',
    name: 'Authentication & Role-Based Access Control (RBAC)',
    category: 'Security & RBAC',
    description: 'Ensure RBAC policies lock administrative mutation actions for unauthorized roles',
    status: 'passed',
    durationMs: 50,
    steps: [
      'Simulate Customer role attempting product deletion',
      'Intercept request via RBAC authorization gate',
      'Assert HTTP 403 / UI Lock feedback is presented',
      'Log security warning into real-time Audit Trail'
    ]
  },
  {
    id: 'test-sec-1',
    name: 'XSS & Input Sanitization Guard',
    category: 'Security & RBAC',
    description: 'Verify that HTML script tags in product descriptions or search terms are stripped cleanly',
    status: 'passed',
    durationMs: 19,
    steps: [
      'Inject payload: <script>alert("XSS")</script> into product description',
      'Pass through DOM/string sanitizer filter',
      'Assert sanitized output contains safe plain text only'
    ]
  },
  {
    id: 'test-cart-1',
    name: 'Cart Math & Checkout Integrity',
    category: 'Cart & Orders',
    description: 'Verify subtotal calculations, tax rates, coupon discount deductions, and stock decrements',
    status: 'passed',
    durationMs: 44,
    steps: [
      'Add multiple product quantities to cart state',
      'Compute subtotal = sum(price * qty)',
      'Apply promo code "APEX20" for 20% discount deduction',
      'Compute sales tax (8.25%) and final order total'
    ]
  }
];

export const DEFAULT_CERTIFICATE_DATA: InternshipCertificateData = {
  studentName: 'Darsini Gedda',
  internId: 'APX-INT-2026-084',
  domain: 'Full Stack Web Development',
  taskTitle: 'Task 5: Final Integrated Project & Certification',
  timeline: '12 Days (Sprint Completed)',
  completionDate: 'September 2, 2026',
  grade: 'Grade A+ (Distinction)',
  mentorName: 'Dr. Rajesh Verma, Lead Architect',
  companyName: 'ApexPlanet Software Pvt Ltd',
  certificateId: 'APX-CERT-FSD-889104',
  verificationCode: 'VERIFIED-APEX-HASH-99824'
};
